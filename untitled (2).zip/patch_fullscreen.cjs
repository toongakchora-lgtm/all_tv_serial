const fs = require('fs');
let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

const fullscreenBtn = `
          <button className="control-btn fullscreen" aria-label="Fullscreen" onClick={(e) => {
            e.stopPropagation();
            const el = videoRef.current?.parentElement;
            if (el) {
              if (document.fullscreenElement) {
                document.exitFullscreen();
              } else {
                if (el.requestFullscreen) {
                  el.requestFullscreen().then(() => {
                    if (window.screen && window.screen.orientation && window.screen.orientation.lock) {
                      window.screen.orientation.lock('landscape').catch(() => {});
                    }
                  }).catch(() => {});
                } else if ((el as any).webkitRequestFullscreen) {
                  (el as any).webkitRequestFullscreen();
                }
              }
            }
          }} style={{ position: 'absolute', bottom: '16px', right: '16px', width: '40px', height: '40px' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width: '20px', height: '20px'}}>
              <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
            </svg>
          </button>
        </div>
`;

code = code.replace(
  '            </svg>\n          </button>\n        </div>',
  '            </svg>\n          </button>\n' + fullscreenBtn
);

fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
