const fs = require('fs');
let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

const fullscreenBtn = `
          <button className="control-btn fullscreen" aria-label="Fullscreen" onClick={(e) => {
            e.stopPropagation();
            const container = videoRef.current?.parentElement as any;
            const video = videoRef.current as any;
            if (container) {
              const isFullscreen = document.fullscreenElement || (document as any).webkitFullscreenElement;
              if (isFullscreen) {
                if (document.exitFullscreen) {
                  document.exitFullscreen();
                } else if ((document as any).webkitExitFullscreen) {
                  (document as any).webkitExitFullscreen();
                }
                try {
                  if (window.screen && window.screen.orientation && window.screen.orientation.unlock) {
                    window.screen.orientation.unlock();
                  }
                } catch(e) {}
              } else {
                const reqFs = container.requestFullscreen || container.webkitRequestFullscreen || container.mozRequestFullScreen || container.msRequestFullscreen;
                
                const lockLandscape = () => {
                  try {
                    if (window.screen && window.screen.orientation && (window.screen.orientation as any).lock) {
                      (window.screen.orientation as any).lock('landscape').catch((err: any) => console.log("Orientation lock failed:", err));
                    } else if (window.screen && (window.screen as any).lockOrientation) {
                      (window.screen as any).lockOrientation('landscape');
                    } else if (window.screen && (window.screen as any).mozLockOrientation) {
                      (window.screen as any).mozLockOrientation('landscape');
                    } else if (window.screen && (window.screen as any).msLockOrientation) {
                      (window.screen as any).msLockOrientation('landscape');
                    }
                  } catch(err) {
                    console.log("Error locking orientation:", err);
                  }
                };

                if (reqFs) {
                  const p = reqFs.call(container);
                  if (p && p.then) {
                    p.then(lockLandscape).catch((e: any) => console.error("Fullscreen failed:", e));
                  } else {
                    lockLandscape();
                  }
                } else if (video && video.webkitEnterFullscreen) {
                  // Fallback for iOS iPhone
                  video.webkitEnterFullscreen();
                } else {
                  console.log("Fullscreen not supported");
                }
              }
            }
          }} style={{ position: 'absolute', bottom: '16px', right: '16px', width: '40px', height: '40px', zIndex: 10 }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width: '20px', height: '20px'}}>
              <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
            </svg>
          </button>
        </div>
`;

code = code.replace(
  /          <button className="control-btn fullscreen"[\s\S]*?<\/button>\s*<\/div>/,
  fullscreenBtn.trim() + '\n'
);

fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
