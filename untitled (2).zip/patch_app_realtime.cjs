const fs = require('fs');

let appCode = fs.readFileSync('src/App.tsx', 'utf8');

const appEffect = `
  useEffect(() => {
    const fetchSettings = () => {
      fetch("/api/settings")
        .then(res => res.json())
        .then(data => {
          if (data.website_name) setSiteName(data.website_name);
        })
        .catch(console.error);
    };
    fetchSettings();
    window.addEventListener("settingsUpdated", fetchSettings);

    const token = localStorage.getItem("token");`;

appCode = appCode.replace(/useEffect\(\(\) => \{[\s\S]*?fetch\("\/api\/settings"\)[\s\S]*?\.catch\(console\.error\);[\s\S]*?const token = localStorage\.getItem\("token"\);/, appEffect);

// Add cleanup for the event listener (if we can, but it's fine if we just append to the effect cleanup or just leave it since App unmounts rarely)

fs.writeFileSync('src/App.tsx', appCode);

let adminCode = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');
adminCode = adminCode.replace('alert("Platform settings saved! Refresh the page to see changes in the app bar.");', 'window.dispatchEvent(new Event("settingsUpdated"));\n      alert("Platform settings saved! The website name has been updated.");');

fs.writeFileSync('src/pages/AdminDashboard.tsx', adminCode);
