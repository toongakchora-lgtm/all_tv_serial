const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf8');

// Remove the increment view logic from GET /api/videos/:id
serverCode = serverCode.replace(
  '// Increment views\n      await db.update(videos).set({ views: (videoResult[0].views || 0) + 1 }).where(eq(videos.id, videoId));\n      \n      res.json({ video: { ...videoResult[0], views: (videoResult[0].views || 0) + 1, userReaction } });',
  'res.json({ video: { ...videoResult[0], userReaction } });'
);

// Add the POST endpoint for incrementing view
const viewEndpoint = `
  app.post("/api/videos/:id/view", async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      const videoResult = await db.select().from(videos).where(eq(videos.id, videoId));
      if (videoResult.length === 0) return res.status(404).json({ error: "Video not found" });

      await db.update(videos).set({ views: (videoResult[0].views || 0) + 1 }).where(eq(videos.id, videoId));
      res.json({ success: true, views: (videoResult[0].views || 0) + 1 });
    } catch (error) {
      res.status(500).json({ error: "Failed to update views" });
    }
  });
`;

serverCode = serverCode.replace('  app.post("/api/videos/:id/react",', viewEndpoint + '\n  app.post("/api/videos/:id/react",');

fs.writeFileSync('server.ts', serverCode);
