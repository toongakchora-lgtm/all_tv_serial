const fs = require('fs');
let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

code = code.replace(
  'const [showControls, setShowControls] = useState(true);',
  'const [showControls, setShowControls] = useState(true);\n  const controlsTimeoutRef = React.useRef<any>(null);\n\n  const resetControlsTimeout = () => {\n    setShowControls(true);\n    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);\n    controlsTimeoutRef.current = setTimeout(() => {\n      if (!videoRef.current?.paused) setShowControls(false);\n    }, 2000);\n  };\n\n  React.useEffect(() => {\n    resetControlsTimeout();\n    return () => {\n      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);\n    };\n  }, [isPaused]);'
);

code = code.replace(
  /onMouseEnter=\{\(\) => setShowControls\(true\)\}\s*onMouseLeave=\{\(\) => setShowControls\(false\)\}\s*onClick=\{\(\) => \{[\s\S]*?setIsPaused\(true\);\s*\}\s*\}\s*\}\}/,
  `onMouseMove={resetControlsTimeout}
           onMouseLeave={() => { if (!isPaused) setShowControls(false); }}
           onClick={() => {
             resetControlsTimeout();
             if (videoRef.current) {
               if (isPaused) {
                 videoRef.current.play();
                 setIsPaused(false);
               } else {
                 videoRef.current.pause();
                 setIsPaused(true);
               }
             }
           }}`
);

// make sure control buttons don't propagate click so they can handle play/pause
// wait, the custom control button already does \`e.stopPropagation()\` and play/pause. Let's make sure it calls resetControlsTimeout too.

fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
