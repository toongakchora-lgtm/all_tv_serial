const fs = require('fs');

let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

// Add state for settings
const stateCode = `  const [websiteName, setWebsiteName] = useState("SK Stream");
  const [supportEmail, setSupportEmail] = useState("support@skstream.in");

  useEffect(() => {
    fetch("/api/settings")
      .then(res => res.json())
      .then(data => {
        if (data.website_name) setWebsiteName(data.website_name);
        if (data.support_email) setSupportEmail(data.support_email);
      })
      .catch(console.error);
  }, []);

  const handleSaveSettings = async () => {
    try {
      const token = localStorage.getItem("token");
      await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Authorization": \`Bearer \${token}\` },
        body: JSON.stringify({ key: "website_name", value: websiteName })
      });
      await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Authorization": \`Bearer \${token}\` },
        body: JSON.stringify({ key: "support_email", value: supportEmail })
      });
      alert("Platform settings saved! Refresh the page to see changes in the app bar.");
    } catch (error) {
      console.error("Failed to save settings", error);
      alert("Failed to save settings.");
    }
  };
`;

code = code.replace('  const [uploadProgress, setUploadProgress] = useState<number | null>(null);', '  const [uploadProgress, setUploadProgress] = useState<number | null>(null);\n\n' + stateCode);

// Update inputs
code = code.replace('<input defaultValue="SK Stream" style={{display: \'block\', width: \'100%\', marginTop: \'6px\', padding: \'10px\', borderRadius: \'8px\', border: \'1px solid var(--line)\'}} />', '<input value={websiteName} onChange={(e) => setWebsiteName(e.target.value)} style={{display: \'block\', width: \'100%\', marginTop: \'6px\', padding: \'10px\', borderRadius: \'8px\', border: \'1px solid var(--line)\'}} />');
code = code.replace('<input defaultValue="support@skstream.in" style={{display: \'block\', width: \'100%\', marginTop: \'6px\', padding: \'10px\', borderRadius: \'8px\', border: \'1px solid var(--line)\'}} />', '<input value={supportEmail} onChange={(e) => setSupportEmail(e.target.value)} style={{display: \'block\', width: \'100%\', marginTop: \'6px\', padding: \'10px\', borderRadius: \'8px\', border: \'1px solid var(--line)\'}} />');
code = code.replace('onClick={() => alert(\'Platform settings saved\')}>Save Changes', 'onClick={handleSaveSettings}>Save Changes');

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
