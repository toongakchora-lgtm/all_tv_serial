const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes('import Profile from "./pages/Profile";')) {
  code = code.replace(
    'import Library from "./pages/Library";',
    'import Library from "./pages/Library";\nimport Profile from "./pages/Profile";'
  );
}

// Replace the inline Profile route
const inlineProfileMatch = /<Route path="\/profile".*?<\/div>\s*}/s;
if (inlineProfileMatch.test(code)) {
  code = code.replace(
    inlineProfileMatch,
    '<Route path="/profile" element={<Profile user={user} setUser={setUser} />}'
  );
} else {
  console.log("Could not find inline Profile route.");
}

fs.writeFileSync('src/App.tsx', code);
