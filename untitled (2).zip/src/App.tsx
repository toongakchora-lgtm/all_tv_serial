/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from "react-router-dom";
import Home from "./pages/Home";
import Discover from "./pages/Discover";
import SearchPage from "./pages/Search";
import Library from "./pages/Library";
import Profile from "./pages/Profile";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Upload from "./pages/Upload";
import VideoPlayer from "./pages/VideoPlayer";
import AdminDashboard from "./pages/AdminDashboard";
import { Play, Search, Compass, Bookmark, User as UserIcon, Home as HomeIcon } from "lucide-react";

import PlatformVideos from "./pages/PlatformVideos";
import TelegramPopup from "./components/TelegramPopup";

function Navigation({ user, siteName }: any) {
  const location = useLocation();
  const path = location.pathname;

  return (
    <>
      <header className="topbar">
        <Link to="/" className="logo">
          <span className="logo-mark"><Play width={20} fill="currentColor" /></span>
          <span>{siteName || "SK Stream"}</span>
        </Link>
        <nav className="desktop-nav">
          <Link to="/" className={path === '/' ? 'active' : ''}>Home</Link>
          <Link to="/discover" className={path === '/discover' ? 'active' : ''}>Discover</Link>
          <Link to="/search" className={path === '/search' ? 'active' : ''}>Search</Link>
          <Link to="/library" className={path === '/library' ? 'active' : ''}>Library</Link>
          {user && <Link to="/profile" className={path === '/profile' ? 'active' : ''}>Profile</Link>}
        </nav>
        <div className="top-actions">
          <Link to="/search" className="icon-btn"><Search width={18} /></Link>
          <Link to="/library" className="icon-btn" style={{ marginLeft: "8px" }}><Bookmark width={18} /></Link>
          {user?.role === 'admin' ? (
            <Link to="/admin" className="pill-btn primary desktop-only">Admin</Link>
          ) : !user ? (
            <Link to="/login" className="pill-btn primary">Login</Link>
          ) : (
            <Link to="/profile" className="icon-btn"><UserIcon width={18} /></Link>
          )}
        </div>
      </header>

      <nav className="bottom-nav">
        <Link to="/" className={path === '/' ? 'active' : ''}>
          <span className="ico"><HomeIcon width={22} /></span><span>Home</span>
        </Link>
        <Link to="/discover" className={path === '/discover' ? 'active' : ''}>
          <span className="ico"><Compass width={22} /></span><span>Discover</span>
        </Link>
        <Link to="/search" className={path === '/search' ? 'active' : ''}>
          <span className="ico"><Search width={22} /></span><span>Search</span>
        </Link>
        <Link to="/library" className={path === '/library' ? 'active' : ''}>
          <span className="ico"><Bookmark width={22} /></span><span>Library</span>
        </Link>
        <Link to={user ? "/profile" : "/login"} className={path === '/profile' || path === '/login' ? 'active' : ''}>
          <span className="ico"><UserIcon width={22} /></span><span>Profile</span>
        </Link>
      </nav>
    </>
  );
}

function MainAppLayout({ user, setUser, siteName }: any) {
  const handleLogout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  return (
    <div className="app">
      <TelegramPopup />
      <Navigation user={user} siteName={siteName} />
      
      <main>
        <Routes>
          <Route path="/" element={<Home siteName={siteName} />} />
          <Route path="/discover" element={<Discover />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/library" element={<Library />} />
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/register" element={<Register setUser={setUser} />} />
          <Route path="/upload" element={<Upload user={user} />} />
          <Route path="/video/:id" element={<VideoPlayer user={user} />} />
          <Route path="/platform/:id" element={<PlatformVideos />} />
          <Route path="/profile" element={<Profile user={user} setUser={setUser} />} />
          <Route path="*" element={
            <div style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--muted)' }}>
              <h2>Coming Soon</h2>
              <p>This page is currently under construction.</p>
            </div>
          } />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [siteName, setSiteName] = useState("SK Stream");

  
  useEffect(() => {
    const fetchSettings = () => {
      fetch("/api/settings")
        .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
        .then(data => {
          if (data.website_name) setSiteName(data.website_name);
        })
        .catch(console.error);
    };
    fetchSettings();
    window.addEventListener("settingsUpdated", fetchSettings);

    const token = localStorage.getItem("token");
    if (token) {
      fetch("/api/auth/me", {
        headers: { "Authorization": `Bearer ${token}` }
      })
      .then(async res => {
        if (!res.ok) throw new Error("Not logged in");
        const text = await res.text();
        try {
          return JSON.parse(text);
        } catch (e) {
          throw new Error("Invalid response");
        }
      })
      .then(data => {
        if (data.user) setUser(data.user);
      })
      .catch(console.error)
      .finally(() => setAuthLoading(false));
    } else {
      setAuthLoading(false);
    }
  }, []);

  if (authLoading) return null;

  return (
    <Router>
      <Routes>
        <Route path="/admin" element={<AdminDashboard user={user} setUser={setUser} siteName={siteName} />} />
        <Route path="*" element={<MainAppLayout user={user} setUser={setUser} siteName={siteName} />} />
      </Routes>
    </Router>
  );
}
