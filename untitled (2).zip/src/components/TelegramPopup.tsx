import React, { useState, useEffect } from 'react';

export default function TelegramPopup() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const hasSeenPopup = localStorage.getItem('sk_telegram_popup_seen');
    if (!hasSeenPopup) {
      // Small delay to make it feel natural
      const timer = setTimeout(() => {
        setShow(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setShow(false);
    localStorage.setItem('sk_telegram_popup_seen', 'true');
  };

  if (!show) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0,0,0,0.6)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 999999,
      padding: '16px'
    }}>
      <div style={{
        width: '520px',
        maxWidth: '95vw',
        background: 'linear-gradient(135deg,#10131d,#171c29)',
        borderRadius: '34px',
        padding: '28px',
        position: 'relative',
        textAlign: 'center',
        boxShadow: '0 20px 45px rgba(0,0,0,.35)',
        fontFamily: 'Arial, sans-serif'
      }}>
        <button 
          onClick={handleClose}
          style={{
            position: 'absolute',
            top: '14px',
            right: '14px',
            width: '42px',
            height: '42px',
            border: 'none',
            borderRadius: '50%',
            background: '#232b3a',
            color: '#a8b0be',
            fontSize: '26px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            paddingBottom: '4px'
          }}
        >
          &times;
        </button>

        <div style={{
          width: '90px',
          height: '90px',
          margin: '5px auto 20px',
          background: '#28A8EA',
          borderRadius: '22px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <svg width="52" height="52" viewBox="0 0 24 24" style={{ fill: '#fff' }}>
            <path d="M21.5 3.5 2.8 10.7c-1.3.5-1.3 1.2-.2 1.6l4.8 1.5 1.9 6c.2.7.1 1 .9 1 .6 0 .9-.3 1.2-.7l2.3-2.2 4.8 3.5c.9.5 1.5.3 1.7-.9L23 4.9c.3-1.3-.5-1.9-1.5-1.4z"/>
          </svg>
        </div>

        <h2 style={{ color: '#fff', fontSize: '34px', marginBottom: '14px', fontWeight: 'normal' }}>
          Join The Community!
        </h2>
        <p style={{ color: '#b8c0cd', fontSize: '17px', lineHeight: '1.6', marginBottom: '26px' }}>
          Get instant access to daily serial updates, latest notifications and exclusive content.
        </p>

        <a 
          href="https://t.me/daily_serial_website" 
          target="_blank"
          rel="noreferrer"
          onClick={handleClose}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '10px',
            width: '100%',
            height: '62px',
            background: '#28A8EA',
            color: '#fff',
            textDecoration: 'none',
            fontSize: '21px',
            fontWeight: 700,
            borderRadius: '18px'
          }}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" style={{ fill: '#fff' }}>
            <path d="M21.5 3.5 2.8 10.7c-1.3.5-1.3 1.2-.2 1.6l4.8 1.5 1.9 6c.2.7.1 1 .9 1 .6 0 .9-.3 1.2-.7l2.3-2.2 4.8 3.5c.9.5 1.5.3 1.7-.9L23 4.9c.3-1.3-.5-1.9-1.5-1.4z"/>
          </svg>
          JOIN TELEGRAM
        </a>
      </div>
    </div>
  );
}
