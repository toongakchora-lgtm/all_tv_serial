import { getStorage } from 'firebase/storage';
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyBSsZzfdI7foTCy9VKuPyD265oMF11ylxE",
  authDomain: "trend-video-6b21f.firebaseapp.com",
  databaseURL: "https://trend-video-6b21f-default-rtdb.firebaseio.com",
  projectId: "trend-video-6b21f",
  storageBucket: "trend-video-6b21f.firebasestorage.app",
  messagingSenderId: "395045734056",
  appId: "1:395045734056:web:3ecc586a7e4db7137e249d",
  measurementId: "G-68LT5WN8FM"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Initialize Analytics (optional, requires browser environment)
export const getFirebaseAnalytics = () => {
  if (typeof window !== "undefined") {
    return getAnalytics(app);
  }
  return null;
};

export const storage = getStorage(app);
