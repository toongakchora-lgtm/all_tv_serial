import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Play, MoreVertical, ThumbsUp, MessageCircle, Bookmark, ArrowLeft } from "lucide-react";

const platformNames: Record<string, string> = {
  'pw': 'Physics Wallah',
  'next-toppers': 'Next Toppers',
  'mission-jeet': 'Mission JEET',
  'rwa': 'RWA',
  'unacademy': 'Unacademy'
};

export default function PlatformVideos() {
  const { id } = useParams();
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const platformName = platformNames[id || ''] || 'Videos';

  useEffect(() => {
    fetch("/api/videos")
      .then(async res => {
        if (!res.ok) return { videos: [] };
        const text = await res.text();
        try {
          return JSON.parse(text);
        } catch(e) {
          return { videos: [] };
        }
      })
      .then(data => {
        if (data.videos) {
          // In a real app we'd filter by platform ID.
          // For now, we'll show approved videos as mock data for the platform.
          setVideos(data.videos.filter((v: any) => v.status === "approved"));
        }
      })
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <div style={{ paddingBottom: '80px', minHeight: '100vh' }}>
      <header style={{ 
        position: 'sticky', top: 0, zIndex: 30, background: 'rgba(0,0,0,0.8)', 
        backdropFilter: 'blur(16px)', display: 'flex', alignItems: 'center', padding: '15px 20px', gap: '15px', borderBottom: '1px solid var(--line)'
      }}>
        <Link to="/" style={{ color: '#fff', textDecoration: 'none', display: 'flex', alignItems: 'center' }}>
          <ArrowLeft width={20} />
        </Link>
        <h2 style={{ margin: 0, fontSize: '18px', fontWeight: 700 }}>{platformName}</h2>
      </header>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)', fontSize: '14px' }}>Loading videos...</div>
      ) : videos.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)', fontSize: '14px' }}>No videos available for {platformName}.</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', paddingTop: '15px', paddingLeft: '15px', paddingRight: '15px' }}>
          {videos.map(video => (
            <Link to={`/video/${video.id}`} key={video.id} style={{ 
              display: 'block', textDecoration: 'none', color: 'inherit',
              background: '#0c100e', border: '1px solid var(--line)', borderRadius: '16px', overflow: 'hidden',
              boxShadow: '0 8px 22px rgba(0,0,0,0.5)'
            }}>
              <div style={{ width: '100%', aspectRatio: '16/9', position: 'relative', background: '#1c1c28' }}>
                <img 
                  src={video.thumbnail || "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1100&q=80"} 
                  alt={video.title} 
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
                />
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg, rgba(5,5,8,.92), transparent 58%)' }}></div>
                <span style={{ 
                  position: 'absolute', bottom: '8px', right: '8px', background: 'rgba(0,0,0,0.8)', color: '#fff', 
                  padding: '4px 8px', borderRadius: '8px', fontSize: '11px', fontWeight: 800, zIndex: 2
                }}>
                  {(video.duration || 0).toFixed(2).replace('.', ':')}
                </span>
                <button style={{
                  position: 'absolute', top: '8px', right: '8px', width: '34px', height: '34px', borderRadius: '50%',
                  background: 'rgba(255,255,255,0.92)', border: '1px solid rgba(255,255,255,0.7)',
                  color: '#1e3a8a', fontSize: '18px', display: 'grid', placeItems: 'center', zIndex: 3, cursor: 'pointer'
                }} onClick={(e) => { e.preventDefault(); }}>
                  ♡
                </button>
              </div>
              <div style={{ padding: '12px' }}>
                <div style={{ fontSize: '15px', fontWeight: 800, lineHeight: 1.35, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', marginBottom: '8px' }}>
                  {video.title}
                </div>
                <div style={{ color: 'var(--muted)', fontSize: '12px', display: 'flex', gap: '8px' }}>
                  <span>{platformName}</span>
                  <span>•</span>
                  <span>{video.views || 0} Views</span>
                  <span>•</span>
                  <span>{new Date(video.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
