import React, { useState, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { Play, Home, Video, Grid2X2, Image as ImageIcon, Users, IndianRupee, Settings, Menu } from "lucide-react";
import "./AdminDashboard.css";

export default function AdminDashboard({ user, setUser, siteName }: any) {
  const [videos, setVideos] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [comments, setComments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVideo, setEditingVideo] = useState<any>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);

  const [websiteName, setWebsiteName] = useState("SK Stream");
  const [supportEmail, setSupportEmail] = useState("support@skstream.in");

  useEffect(() => {
    fetch("/api/settings")
      .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
      .then(data => {
        if (data.website_name) setWebsiteName(data.website_name);
        if (data.support_email) setSupportEmail(data.support_email);
        if (data.homepage_sections) {
          try { setHomeSections(JSON.parse(data.homepage_sections)); } catch(e) {}
        } else {
          setHomeSections([
            { id: "1", title: "Continue Watching", type: "continue_watching", landscape: true },
            { id: "2", title: "Short Dramas", type: "category", category: "Short Dramas", landscape: false },
            { id: "3", title: "Movies & Web Series", type: "category", category: "Movies", landscape: true },
            { id: "4", title: "Trending Now", type: "trending", landscape: false }
          ]);
        }
      })
      .catch(console.error);
  }, []);

  
  const saveHomeSections = async (sectionsToSave: any[]) => {
    const token = localStorage.getItem("token");
    try {
      await fetch("/api/admin/settings", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ key: "homepage_sections", value: JSON.stringify(sectionsToSave) })
      });
      setHomeSections(sectionsToSave);
      alert("Sections saved successfully!");
    } catch(e) {
      console.error(e);
      alert("Failed to save sections");
    }
  };

  const handleSaveSettings = async () => {
    try {
      const token = localStorage.getItem("token");
      await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify({ key: "website_name", value: websiteName })
      });
      await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
        body: JSON.stringify({ key: "support_email", value: supportEmail })
      });
      window.dispatchEvent(new Event("settingsUpdated"));
      alert("Platform settings saved! The website name has been updated.");
    } catch (error) {
      console.error("Failed to save settings", error);
      alert("Failed to save settings.");
    }
  };


  const [categories, setCategories] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('sk_categories');
      if (stored) return JSON.parse(stored);
    } catch(e) {}
    return ['Romance', 'Thriller', 'Family', 'Comedy', 'Action', 'Drama'];
  });
  const [newCategory, setNewCategory] = useState("");

  const [banners, setBanners] = useState<any[]>([]);
  const [homeSections, setHomeSections] = useState<any[]>([]);
  const [newBannerTitle, setNewBannerTitle] = useState("");
  const [newBannerImages, setNewBannerImages] = useState<File[]>([]);

  const fetchBanners = () => {
    fetch("/api/banners")
      .then(async res => {
        if (!res.ok) return {};
        try {
          return JSON.parse(await res.text());
        } catch (e) {
          return {};
        }
      })
      .then(data => {
        if (data.banners) setBanners(data.banners);
      })
      .catch(() => {});
  };

  const addBanner = async () => {
    const val = newBannerTitle.trim() || "New Banner";
    if (newBannerImages.length === 0) {
      alert("Please select at least one image");
      return;
    }

    const checkAspectRatio = (file) => {
      return new Promise((resolve) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => {
          const ratio = img.width / img.height;
          if (ratio >= 1.7 && ratio <= 1.8) resolve(true);
          else resolve(false);
          URL.revokeObjectURL(url);
        };
        img.onerror = () => resolve(false);
        img.src = url;
      });
    };

    for (const img of newBannerImages) {
      const isValid = await checkAspectRatio(img);
      if (!isValid) {
        alert("Only 16:9 aspect ratio images are allowed.");
        return;
      }
    }

    const formData = new FormData();
    formData.append("title", val);
    for (let i = 0; i < newBannerImages.length; i++) {
      formData.append("images", newBannerImages[i]);
    }

    const token = localStorage.getItem("token");
    try {
      const res = await fetch("/api/admin/banners", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData
      });
      if (res.ok) {
        setNewBannerTitle("");
        setNewBannerImages([]);
        fetchBanners();
      } else {
        alert("Failed to upload banner");
      }
    } catch (e) {
      alert("Upload error");
    }
  };

  const toggleBanner = async (id: number) => {
    const token = localStorage.getItem("token");
    await fetch(`/api/admin/banners/${id}/active`, {
      method: "PUT",
      headers: { Authorization: `Bearer ${token}` }
    });
    fetchBanners();
  };

  const deleteBanner = async (id: number) => {
    if (!window.confirm("Delete banner?")) return;
    const token = localStorage.getItem("token");
    await fetch(`/api/admin/banners/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` }
    });
    fetchBanners();
  };

  const [adsEnabled, setAdsEnabled] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('sk_ads_enabled');
      if (stored) return JSON.parse(stored);
    } catch(e) {}
    return true;
  });

  const toggleAds = () => {
    const updated = !adsEnabled;
    setAdsEnabled(updated);
    localStorage.setItem('sk_ads_enabled', JSON.stringify(updated));
  };

  const addCategory = () => {
    const val = newCategory.trim();
    if (val && !categories.includes(val)) {
      const updated = [...categories, val];
      setCategories(updated);
      localStorage.setItem('sk_categories', JSON.stringify(updated));
      setNewCategory("");
    }
  };

  const deleteCategory = (cat: string) => {
    if (window.confirm(`Delete category ${cat}?`)) {
      const updated = categories.filter(c => c !== cat);
      setCategories(updated);
      localStorage.setItem('sk_categories', JSON.stringify(updated));
    }
  };

  const fetchVideos = () => {
    const token = localStorage.getItem("token");
    fetch("/api/admin/videos", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(async res => {
        if (!res.ok) return { videos: [] };
        const text = await res.text();
        try {
          return JSON.parse(text);
        } catch (e) {
          console.error("Failed to parse JSON:", text);
          return { videos: [] };
        }
      })
      .then(data => {
        if (data.videos) setVideos(data.videos);
      })
      .finally(() => setLoading(false));
  };

  
  const deleteComment = async (id: number) => {
    if (window.confirm("Are you sure you want to delete this comment?")) {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(`/api/admin/comments/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          fetchComments();
        } else {
          alert("Failed to delete comment");
        }
      } catch(e) {
        alert("Error deleting comment");
      }
    }
  };

  const fetchComments = () => {
    const token = localStorage.getItem("token");
    fetch("/api/admin/comments", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
      .then(data => {
        if (data.comments) setComments(data.comments);
      })
      .catch(console.error);
  };

  const fetchUsers = () => {
    const token = localStorage.getItem("token");
    fetch("/api/admin/users", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(async res => {
        if (!res.ok) return { users: [] };
        const text = await res.text();
        try {
          return JSON.parse(text);
        } catch (e) {
          return { users: [] };
        }
      })
      .then(data => {
        if (data.users) setUsers(data.users);
      });
  };

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchVideos();
      fetchUsers();
    fetchComments();
      fetchBanners();
      const interval = setInterval(() => {
        fetchVideos();
        fetchUsers();
        fetchBanners();
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  const handleAction = async (id: number, action: 'approve' | 'reject') => {
    const reason = action === 'reject' ? prompt("Reason for rejection:") : "";
    if (action === 'reject' && reason === null) return;

    const token = localStorage.getItem("token");
    await fetch(`/api/admin/videos/${id}/${action}`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify({ reason })
    });
    fetchVideos();
  };

  const toggleStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'approved' ? 'pending' : (currentStatus === 'pending' ? 'rejected' : 'approved');
    const token = localStorage.getItem("token");
    await fetch(`/api/admin/videos/${id}`, {
      method: "PUT",
      headers: { 
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}` 
      },
      body: JSON.stringify({ status: newStatus })
    });
    fetchVideos();
  };

  const toggleUserStatus = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'blocked' : 'active';
    const token = localStorage.getItem("token");
    try {
      await fetch(`/api/admin/users/${id}/status`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status: newStatus })
      });
      fetchUsers();
    } catch (e) {
      console.error(e);
    }
  };

  const deleteVideo = async (id: number) => {
    if (!confirm("Are you sure you want to delete this video?")) return;
    const token = localStorage.getItem("token");
    await fetch(`/api/admin/videos/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` }
    });
    fetchVideos();
  };

  const handleSaveVideo = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    // Convert to proper status strings for backend
    const statusVal = formData.get("status") as string;
    let dbStatus = "approved";
    if (statusVal === "draft") dbStatus = "pending";
    if (statusVal === "off") dbStatus = "rejected";
    if (statusVal === "live") dbStatus = "approved";
    formData.set("status", dbStatus);

    const token = localStorage.getItem("token");
    
    const url = editingVideo ? `/api/admin/videos/${editingVideo.id}` : "/api/admin/videos/add";
    const method = editingVideo ? "PUT" : "POST";
    
    try {
      setUploadProgress(0);

      const videoFile = formData.get("videoFile") as File;
      if (videoFile && videoFile.size > 0) {
        const chunkSize = 10 * 1024 * 1024; // 10MB
        const totalChunks = Math.ceil(videoFile.size / chunkSize);
        const uploadId = crypto.randomUUID();
        
        for (let i = 0; i < totalChunks; i++) {
          const start = i * chunkSize;
          const end = Math.min(start + chunkSize, videoFile.size);
          const chunk = videoFile.slice(start, end);

          const fd = new FormData();
          fd.append("chunk", chunk);
          fd.append("uploadId", uploadId);
          fd.append("chunkIndex", i.toString());
          fd.append("totalChunks", totalChunks.toString());
          if (i === totalChunks - 1) fd.append("originalName", videoFile.name);

          const res = await fetch("/api/upload-chunk", {
            method: "POST",
            headers: token ? { Authorization: `Bearer ${token}` } : {},
            body: fd,
          });

          if (!res.ok) throw new Error("Video chunk upload failed");
          const data = await res.json();
          
          setUploadProgress(Math.round(((i + 1) / totalChunks) * 100));

          if (data.completed) {
            formData.set("video", data.url);
          }
        }
      }
      formData.delete("videoFile");

      const posterFile = formData.get("posterFile") as File;
      if (posterFile && posterFile.size > 0) {
        const chunkSize = 10 * 1024 * 1024;
        const totalChunks = Math.ceil(posterFile.size / chunkSize);
        const uploadId = crypto.randomUUID();
        
        for (let i = 0; i < totalChunks; i++) {
          const start = i * chunkSize;
          const end = Math.min(start + chunkSize, posterFile.size);
          const chunk = posterFile.slice(start, end);

          const fd = new FormData();
          fd.append("chunk", chunk);
          fd.append("uploadId", uploadId);
          fd.append("chunkIndex", i.toString());
          fd.append("totalChunks", totalChunks.toString());
          if (i === totalChunks - 1) fd.append("originalName", posterFile.name);

          const res = await fetch("/api/upload-chunk", {
            method: "POST",
            headers: token ? { Authorization: `Bearer ${token}` } : {},
            body: fd,
          });

          if (!res.ok) throw new Error("Poster chunk upload failed");
          const data = await res.json();
          if (data.completed) {
            formData.set("poster", data.url);
          }
        }
      }
      formData.delete("posterFile");

      setUploadProgress(null);
      
      const finalRes = await fetch(url, {
        method,
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData
      });

      if (finalRes.ok) {
        setIsModalOpen(false);
        fetchVideos();
      } else {
        const errText = await finalRes.text();
        alert("Failed to save video: " + errText);
      }
    } catch (e: any) {
      setUploadProgress(null);
      alert("Error: " + e.message);
    }
  };

  if (user?.role !== 'admin') return <Navigate to="/login" replace />;
  if (loading) return <div style={{padding: '30px', textAlign: 'center'}}>Loading admin panel...</div>;

  const liveCount = videos.filter(v => v.status === 'approved').length;
  const draftCount = videos.filter(v => v.status === 'pending').length;
  
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <Home width={18} /> },
    { id: 'videos', label: 'Videos', icon: <Play width={18} /> },
    { id: 'categories', label: 'Categories', icon: <Grid2X2 width={18} /> },
    { id: 'banners', label: 'Banners', icon: <ImageIcon width={18} /> },
    { id: 'users', label: 'Users', icon: <Users width={18} /> },
    { id: 'ads', label: 'Ads & Revenue', icon: <IndianRupee width={18} /> },
    { id: 'comments', label: 'Comments', icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> },
    { id: 'home_sections', label: 'Home Sections', icon: <Menu width={18} /> },
    { id: 'settings', label: 'Settings', icon: <Settings width={18} /> },
  ];

  const getStatusLabel = (s: string) => {
    if (s === 'approved') return 'Published';
    if (s === 'pending') return 'Draft';
    if (s === 'rejected') return 'Unpublished';
    return s;
  };

  return (
    <div className="admin-app">
      <aside className={`admin-sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="admin-brand">
          <span className="admin-logo"><Play fill="currentColor" width={20} /></span>
          <span>{siteName || "SK Stream"} Admin</span>
        </div>
        <nav className="admin-nav">
          {navItems.map(n => (
            <button key={n.id} className={activeSection === n.id ? 'active' : ''} onClick={() => { setActiveSection(n.id); setSidebarOpen(false); }}>
              {n.icon} <span>{n.label}</span>
            </button>
          ))}
        </nav>
        <div className="admin-sidebar-foot">
          <button onClick={handleLogout}>Logout</button>
        </div>
      </aside>
      
      <div className={`admin-mobile-overlay ${sidebarOpen ? 'show' : ''}`} onClick={() => setSidebarOpen(false)}></div>

      <div className="admin-main">
        <header className="admin-topbar">
          <button className="admin-menu-btn" onClick={() => setSidebarOpen(true)}><Menu width={20} /></button>
          <h2>{navItems.find(n => n.id === activeSection)?.label || 'Admin'}</h2>
          <div className="admin-top-actions">
            <button className="admin-btn">Export</button>
            <button className="admin-btn primary" onClick={() => { setEditingVideo(null); setIsModalOpen(true); }}>+ Add Video</button>
          </div>
        </header>

        <main className="admin-content">
          <section className={`admin-page ${activeSection === 'dashboard' ? 'active' : ''}`}>
            <div className="admin-stats">
              <div className="admin-card admin-stat"><small>Total Videos</small><b>{videos.length}</b></div>
              <div className="admin-card admin-stat"><small>Published</small><b>{liveCount}</b></div>
              <div className="admin-card admin-stat"><small>Drafts</small><b>{draftCount}</b></div>
              <div className="admin-card admin-stat"><small>Total Users</small><b>{users.length}</b></div>
            </div>
            <div className="admin-grid2">
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Weekly Views</h3>
                  <span style={{color: 'var(--good, #10b981)', fontWeight: 800}}>+18.6%</span>
                </div>
                <div className="admin-card-body">
                  <div className="admin-chart">
                    {[38,54,46,72,67,88,79].map((h,i) => (
                      <div key={i} className="admin-bar" style={{height: `${h}%`}}>
                        <span>{['M','T','W','T','F','S','S'][i]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Quick Summary</h3>
                </div>
                <div className="admin-card-body admin-list">
                  <div className="admin-list-item"><b>Categories</b><span>{categories.length}</span></div>
                  <div className="admin-list-item"><b>Premium Users</b><span>{users.filter(u => u.plan === 'Premium').length}</span></div>
                  <div className="admin-list-item"><b>Ads</b><span>Enabled</span></div>
                  <div className="admin-list-item"><b>Total Views</b><span>{videos.reduce((a, b) => a + (b.views || 0), 0)}</span></div>
                </div>
              </div>
            </div>
            <div className="admin-card" style={{marginTop: '14px'}}>
              <div className="admin-card-head">
                <h3>Recent Videos</h3>
                <button className="admin-btn" onClick={() => setActiveSection('videos')}>View All</button>
              </div>
              <div className="admin-card-body admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr><th>Video</th><th>Category</th><th>Views</th><th>Status</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {videos.slice(0, 5).map(v => (
                      <tr key={v.id}>
                        <td>
                          <div style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                            <img className="admin-thumb" src={v.thumbnailUrl || "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1100&q=80"} alt="" />
                            <div>
                              <b style={{color: '#000'}}>{v.title}</b>
                              <div style={{color: 'var(--muted)', fontSize: '12px'}}>{new Date(v.createdAt).getFullYear()}</div>
                            </div>
                          </div>
                        </td>
                        <td>{v.category || 'Drama'}</td>
                        <td>{v.views || 0}</td>
                        <td><span className={`admin-badge ${v.status}`}>{getStatusLabel(v.status)}</span></td>
                        <td>
                          <div className="admin-actions">
                            <button onClick={() => toggleStatus(v.id, v.status)}>Status</button>
                            <button onClick={() => deleteVideo(v.id)}>Delete</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <section className={`admin-page ${activeSection === 'videos' ? 'active' : ''}`}>
            <div className="admin-card">
              <div className="admin-card-head">
                <h3>All Videos</h3>
                <button className="admin-btn primary" onClick={() => { setEditingVideo(null); setIsModalOpen(true); }}>+ Add Video</button>
              </div>
              <div className="admin-card-body admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr><th>Video</th><th>Category</th><th>Views</th><th>Status</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {videos.map(v => (
                      <tr key={v.id}>
                        <td>
                          <div style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                            <img className="admin-thumb" src={v.thumbnailUrl || "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1100&q=80"} alt="" />
                            <div>
                              <b style={{color: '#000'}}>{v.title}</b>
                              <div style={{color: 'var(--muted)', fontSize: '12px'}}>{new Date(v.createdAt).getFullYear()}</div>
                            </div>
                          </div>
                        </td>
                        <td>{v.category || 'Drama'}</td>
                        <td>{v.views || 0}</td>
                        <td><span className={`admin-badge ${v.status}`}>{getStatusLabel(v.status)}</span></td>
                        <td>
                          <div className="admin-actions">
                            <button onClick={() => toggleStatus(v.id, v.status)}>Status</button>
                            <button onClick={() => deleteVideo(v.id)}>Delete</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
          
          <section className={`admin-page ${activeSection === 'categories' ? 'active' : ''}`}>
            <div className="admin-grid2">
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Categories</h3>
                </div>
                <div className="admin-card-body admin-list">
                  {categories.map((c, i) => (
                    <div key={i} className="admin-list-item">
                      <b style={{flex: 1}}>{c}</b>
                      <span style={{color: 'var(--muted)', fontSize: '12px'}}>{videos.filter(x => x.category === c).length} videos</span>
                      <button className="admin-btn danger" style={{background: '#fff1f2', color: '#ef4444', borderColor: '#fecdd3', padding: '5px 10px'}} onClick={() => deleteCategory(c)}>Delete</button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Add Category</h3>
                </div>
                <div className="admin-card-body">
                  <label>Category name<input value={newCategory} onChange={e => setNewCategory(e.target.value)} placeholder="Example: Romance" style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}} /></label>
                  <button className="admin-btn primary" style={{marginTop: '10px', width: '100%'}} onClick={addCategory}>Add Category</button>
                </div>
              </div>
            </div>
          </section>

          <section className={`admin-page ${activeSection === 'banners' ? 'active' : ''}`}>
            <div className="admin-grid2">
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Homepage Banners</h3>
                </div>
                <div className="admin-card-body admin-list">
                  {banners.map(b => (
                    <div key={b.id} className="admin-list-item">
                      {b.imageUrl && <img src={b.imageUrl} alt="Banner" style={{width: '92px', aspectRatio: '16/9', objectFit: 'cover', borderRadius: '9px'}} />}
                      <b style={{flex: 1}}>{b.title}</b>
                      <span style={{color: 'var(--muted)', fontSize: '12px'}}>{b.active ? 'Active' : 'Inactive'}</span>
                      <button className="admin-btn" style={{padding: '5px 10px'}} onClick={() => toggleBanner(b.id)}>{b.active ? 'Disable' : 'Enable'}</button>
                      <button className="admin-btn danger" style={{background: '#fff1f2', color: '#ef4444', borderColor: '#fecdd3', padding: '5px 10px'}} onClick={() => deleteBanner(b.id)}>Delete</button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Add Banner</h3>
                </div>
                <div className="admin-card-body">
                  <label>Banner title<input value={newBannerTitle} onChange={e => setNewBannerTitle(e.target.value)} placeholder="Weekend Special" style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}} /></label>
                  
                  <label style={{display: 'block', marginTop: '12px'}}>Banner image from gallery (16:9 only)
                    <p style={{fontSize: '12px', color: 'var(--muted)', marginTop: '2px'}}>Upload images with 16:9 size (e.g. 1920x1080) for best appearance on mobile and desktop.</p>
                    <input type="file" multiple accept="image/*" onChange={e => setNewBannerImages(Array.from(e.target.files || []))} style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}} />
                  </label>
                  
                  {newBannerImages.length > 0 && (
                    <div style={{marginTop: '12px', display: 'flex', gap: '10px', overflowX: 'auto'}}>
                      {newBannerImages.map((img, i) => (
                        <img key={i} src={URL.createObjectURL(img)} style={{height: '80px', aspectRatio: '16/9', objectFit: 'cover', borderRadius: '8px', border: '1px solid var(--line)'}} alt="Preview" />
                      ))}
                    </div>
                  )}

                  <button className="admin-btn primary" style={{marginTop: '10px', width: '100%'}} onClick={addBanner}>Add Banner</button>
                </div>
              </div>
            </div>
          </section>

          <section className={`admin-page ${activeSection === 'users' ? 'active' : ''}`}>
            <div className="admin-card">
              <div className="admin-card-head">
                <h3>Users</h3>
              </div>
              <div className="admin-card-body admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Plan</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id}>
                        <td><b>{u.displayName || 'Unknown'}</b></td>
                        <td>{u.email}</td>
                        <td>{u.plan || 'Free'}</td>
                        <td>{u.status || 'Active'}</td>
                        <td>
                          <button className="admin-btn" style={{padding: '5px 10px'}} onClick={() => toggleUserStatus(u.id, u.status || 'active')}>
                            {(u.status || 'active') === 'active' ? 'Block' : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    ))}
                    {users.length === 0 && (
                      <tr>
                        <td colSpan={5} style={{textAlign: 'center', color: 'var(--muted)', padding: '20px'}}>No users found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <section className={`admin-page ${activeSection === 'ads' ? 'active' : ''}`}>
            <div className="admin-grid2">
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Ads Control</h3>
                </div>
                <div className="admin-card-body">
                  <div className="admin-list-item">
                    <b style={{flex: 1}}>Video Ads</b>
                    <span style={{color: 'var(--muted)', fontSize: '12px'}}>{adsEnabled ? 'Enabled' : 'Disabled'}</span>
                    <button className={`admin-btn ${adsEnabled ? 'danger' : 'primary'}`} style={adsEnabled ? {background: '#fff1f2', color: '#ef4444', borderColor: '#fecdd3'} : {}} onClick={toggleAds}>
                      {adsEnabled ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                  <div className="admin-list-item" style={{marginTop: '10px'}}>
                    <b style={{flex: 1}}>Estimated Revenue</b>
                    <span style={{color: 'var(--muted)', fontSize: '12px'}}>₹12,450</span>
                  </div>
                  <div className="admin-list-item" style={{marginTop: '10px'}}>
                    <b style={{flex: 1}}>Ad Impressions</b>
                    <span style={{color: 'var(--muted)', fontSize: '12px'}}>48,320</span>
                  </div>
                </div>
              </div>
              
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Revenue Settings</h3>
                </div>
                <div className="admin-card-body admin-form-grid">
                  <label>Currency
                    <select style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}}>
                      <option>INR ₹</option>
                    </select>
                  </label>
                  <label>Ad frequency
                    <select style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}}>
                      <option>Every 2 videos</option>
                      <option>Every 3 videos</option>
                    </select>
                  </label>
                  <label className="admin-full">AdSense Client ID
                    <input placeholder="ca-pub-xxxxxxxx" style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}} />
                  </label>
                  <button className="admin-btn primary admin-full" style={{marginTop: '10px'}} onClick={() => alert('Settings saved')}>Save Settings</button>
                </div>
              </div>
            </div>
          </section>


          <section className={`admin-page ${activeSection === 'comments' ? 'active' : ''}`}>
            <div className="admin-card">
              <div className="admin-card-head">
                <h3>All Comments</h3>
              </div>
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>User</th>
                      <th>Comment</th>
                      <th>Video</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {comments.map(c => (
                      <tr key={c.id}>
                        <td>
                          <div style={{ fontWeight: 600 }}>{c.user?.displayName || 'Unknown'}</div>
                          <div style={{ fontSize: '11px', color: 'var(--muted)' }}>{c.user?.email || ''}</div>
                        </td>
                        <td>{c.text}</td>
                        <td>{c.video?.title || 'Unknown Video'}</td>
                        <td>{new Date(c.createdAt).toLocaleDateString()}</td>
                        <td>
                          <button className="admin-btn" style={{ background: '#ef4444' }} onClick={() => deleteComment(c.id)}>Delete</button>
                        </td>
                      </tr>
                    ))}
                    {comments.length === 0 && (
                      <tr><td colSpan={5} style={{textAlign: 'center', padding: '20px', color: 'var(--muted)'}}>No comments found</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </section>


          <section className={`admin-page ${activeSection === 'home_sections' ? 'active' : ''}`}>
            <div className="admin-grid2">
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Home Page Sections</h3>
                </div>
                <div className="admin-card-body admin-list">
                  {homeSections.map((sec, i) => (
                    <div key={sec.id} className="admin-list-item" style={{flexDirection: 'column', alignItems: 'flex-start', background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid var(--line)'}}>
                      <div style={{display: 'flex', width: '100%', gap: '10px', alignItems: 'center'}}>
                        <input
                          value={sec.title}
                          onChange={e => {
                            const newSec = [...homeSections];
                            newSec[i].title = e.target.value;
                            setHomeSections(newSec);
                          }}
                          style={{flex: 1, padding: '6px 10px', border: '1px solid var(--line)', borderRadius: '6px'}}
                        />
                        <button className="admin-btn" style={{padding: '6px 10px'}} onClick={() => {
                          if (i > 0) {
                            const newSec = [...homeSections];
                            const temp = newSec[i];
                            newSec[i] = newSec[i-1];
                            newSec[i-1] = temp;
                            setHomeSections(newSec);
                          }
                        }}>Up</button>
                        <button className="admin-btn" style={{padding: '6px 10px'}} onClick={() => {
                          if (i < homeSections.length - 1) {
                            const newSec = [...homeSections];
                            const temp = newSec[i];
                            newSec[i] = newSec[i+1];
                            newSec[i+1] = temp;
                            setHomeSections(newSec);
                          }
                        }}>Down</button>
                        <button className="admin-btn danger" style={{background: '#fff1f2', color: '#ef4444', borderColor: '#fecdd3', padding: '6px 10px'}} onClick={() => {
                          if (window.confirm('Delete section?')) {
                            const newSec = homeSections.filter(s => s.id !== sec.id);
                            setHomeSections(newSec);
                          }
                        }}>Delete</button>
                      </div>
                      <div style={{display: 'flex', gap: '10px', marginTop: '10px', fontSize: '13px', color: 'var(--text)', width: '100%', alignItems: 'center', flexWrap: 'wrap'}}>
                        <select
                          value={sec.type}
                          onChange={e => {
                            const newSec = [...homeSections];
                            newSec[i].type = e.target.value;
                            setHomeSections(newSec);
                          }}
                          style={{padding: '6px', borderRadius: '4px', border: '1px solid var(--line)'}}
                        >
                          <option value="continue_watching">Continue Watching</option>
                          <option value="trending">Trending Now</option>
                          <option value="category">Category</option>
                        </select>
                        {sec.type === 'category' && (
                          <input
                            placeholder="Category Name (e.g. Romance)"
                            value={sec.category || ''}
                            onChange={e => {
                              const newSec = [...homeSections];
                              newSec[i].category = e.target.value;
                              setHomeSections(newSec);
                            }}
                            style={{padding: '6px', borderRadius: '4px', border: '1px solid var(--line)', flex: 1}}
                          />
                        )}
                        <label style={{display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 600}}>
                          <input
                            type="checkbox"
                            checked={sec.landscape || false}
                            onChange={e => {
                              const newSec = [...homeSections];
                              newSec[i].landscape = e.target.checked;
                              setHomeSections(newSec);
                            }}
                          />
                          Landscape Cards
                        </label>
                      </div>
                    </div>
                  ))}
                  <button className="admin-btn primary" style={{marginTop: '16px', width: '100%', padding: '12px'}} onClick={() => saveHomeSections(homeSections)}>Save Changes</button>
                </div>
              </div>
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Add New Section</h3>
                </div>
                <div className="admin-card-body">
                  <button className="admin-btn" style={{width: '100%', padding: '10px'}} onClick={() => {
                    const newSec = [...homeSections, { id: Date.now().toString(), title: 'New Section', type: 'category', category: '', landscape: false }];
                    setHomeSections(newSec);
                  }}>+ Add Section</button>
                </div>
              </div>
            </div>
          </section>

          <section className={`admin-page ${activeSection === 'settings' ? 'active' : ''}`}>
            <div className="admin-card">
              <div className="admin-card-head">
                <h3>Platform Settings</h3>
              </div>
              <div className="admin-card-body admin-form-grid">
                <label>Website name
                  <input value={websiteName} onChange={(e) => setWebsiteName(e.target.value)} style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}} />
                </label>
                <label>Support email
                  <input value={supportEmail} onChange={(e) => setSupportEmail(e.target.value)} style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}} />
                </label>
                <label>Default language
                  <select style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}}>
                    <option>Hindi</option>
                    <option>English</option>
                  </select>
                </label>
                <label>Video quality
                  <select style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)'}}>
                    <option>Auto</option>
                    <option>720p</option>
                    <option>1080p</option>
                  </select>
                </label>
                <label className="admin-full">Website description
                  <textarea defaultValue="SK Library style video streaming platform." style={{display: 'block', width: '100%', marginTop: '6px', padding: '10px', borderRadius: '8px', border: '1px solid var(--line)', minHeight: '90px', resize: 'vertical'}}></textarea>
                </label>
                <button className="admin-btn primary admin-full" style={{marginTop: '10px'}} onClick={handleSaveSettings}>Save Changes</button>
              </div>
            </div>
          </section>

        </main>
      </div>

      <div className={`admin-modal ${isModalOpen ? 'open' : ''}`}>
        <div className="admin-sheet">
          <div className="admin-sheet-head">
            <h3>Add Video</h3>
            <button className="admin-close" onClick={() => setIsModalOpen(false)}>×</button>
          </div>
          <div className="admin-sheet-body">
            <form className="admin-form-grid" onSubmit={handleSaveVideo}>
              <label>Video title <input name="title" required placeholder="Example: Dil Ka Faisla" defaultValue={editingVideo?.title} /></label>
              <label>Category
                <select name="genre" defaultValue={editingVideo?.category || categories[0] || 'Romance'}>
                  {categories.map((cat, i) => <option key={i} value={cat}>{cat}</option>)}
                </select>
              </label>
              <label className="admin-full">Description <textarea name="description" required placeholder="Short story description" defaultValue={editingVideo?.description}></textarea></label>
              <label>Poster URL <input name="poster" type="url" placeholder="https://..." defaultValue={editingVideo?.thumbnailUrl} /></label>
              <label>Poster from Gallery <input name="posterFile" type="file" accept="image/*" /></label>
              <label>Video MP4 URL <input name="video" type="url" placeholder="https://..." defaultValue={editingVideo?.videoUrl} /></label>
              <label>Video from Gallery <input name="videoFile" type="file" accept="video/*" /></label>
              <label>Status
                <select name="status" defaultValue={editingVideo?.status || 'live'}>
                  <option value="live">Published</option>
                  <option value="draft">Draft</option>
                  <option value="off">Unpublished</option>
                </select>
              </label>
              <div className="admin-full" style={{display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '10px', alignItems: 'center'}}>
                {uploadProgress !== null && (
                  <div style={{flex: 1, height: '8px', background: '#333', borderRadius: '4px', overflow: 'hidden', marginRight: '10px'}}>
                    <div style={{width: `${uploadProgress}%`, height: '100%', background: '#00d2ff', transition: 'width 0.2s'}}></div>
                  </div>
                )}
                {uploadProgress !== null && <span style={{marginRight: '10px', fontSize: '12px'}}>{uploadProgress}%</span>}
                <button type="button" className="admin-btn" onClick={() => setIsModalOpen(false)} disabled={uploadProgress !== null}>Cancel</button>
                <button className="admin-btn primary" type="submit" disabled={uploadProgress !== null}>
                  {uploadProgress !== null ? "Uploading..." : "Save Video"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

    </div>
  );
}
