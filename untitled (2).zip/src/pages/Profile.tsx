import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Profile({ user, setUser }: any) {
  const navigate = useNavigate();
  const [showPass, setShowPass] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setUser(null);
    navigate("/");
  };

  if (!user) {
    return (
      <div style={{ textAlign: "center", padding: "40px", color: "var(--muted)" }}>
        Please log in to view your profile.
        <br/><br/>
        <Link to="/login" className="btn primary">Login</Link>
      </div>
    );
  }

  const initial = user.displayName ? user.displayName.charAt(0).toUpperCase() : (user.email ? user.email.charAt(0).toUpperCase() : "U");

  return (
    <>
      <div style={{
        background: "#2563eb",
        color: "#fff",
        padding: "18px",
        textAlign: "center",
        fontSize: "22px",
        fontWeight: "bold",
        margin: "-16px -16px 24px -16px",
        borderBottomLeftRadius: "16px",
        borderBottomRightRadius: "16px"
      }}>
        My Profile
      </div>

      <div style={{
        maxWidth: "420px",
        margin: "0 auto 24px auto",
        background: "#fff",
        borderRadius: "18px",
        padding: "24px",
        boxShadow: "0 8px 24px rgba(0,0,0,.08)"
      }}>
        <div style={{
          width: "90px",
          height: "90px",
          borderRadius: "50%",
          margin: "auto",
          background: "linear-gradient(135deg, var(--brand), var(--brand2))",
          color: "#fff",
          fontSize: "38px",
          fontWeight: "bold",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 10px 26px rgba(37,99,235,.2)"
        }}>
          {initial}
        </div>
        <h2 style={{ textAlign: "center", margin: "15px 0 5px", fontSize: "24px", color: "#17233a" }}>{user.displayName || "User"}</h2>
        <div style={{ textAlign: "center", color: "#666", marginBottom: "20px", fontSize: "14px" }}>
          {user.role === "admin" ? "Admin Account" : "SK Stream Member"}
        </div>

        <div style={{ margin: "14px 0" }}>
          <label style={{ display: "block", color: "#666", fontSize: "13px", marginBottom: "6px", fontWeight: 600 }}>Name</label>
          <input 
            value={user.displayName || ""} 
            readOnly 
            style={{ width: "100%", padding: "12px", border: "1px solid #d9e2ef", borderRadius: "10px", fontSize: "15px", boxSizing: "border-box", background: "#f8fafc", color: "#1e293b", outline: "none" }} 
          />
        </div>

        <div style={{ margin: "14px 0" }}>
          <label style={{ display: "block", color: "#666", fontSize: "13px", marginBottom: "6px", fontWeight: 600 }}>Email ID</label>
          <input 
            value={user.email || ""} 
            readOnly 
            style={{ width: "100%", padding: "12px", border: "1px solid #d9e2ef", borderRadius: "10px", fontSize: "15px", boxSizing: "border-box", background: "#f8fafc", color: "#1e293b", outline: "none" }} 
          />
        </div>

        <div style={{ margin: "14px 0" }}>
          <label style={{ display: "block", color: "#666", fontSize: "13px", marginBottom: "6px", fontWeight: 600 }}>Password</label>
          <input 
            value="********" 
            type={showPass ? "text" : "password"} 
            readOnly 
            style={{ width: "100%", padding: "12px", border: "1px solid #d9e2ef", borderRadius: "10px", fontSize: "15px", boxSizing: "border-box", background: "#f8fafc", color: "#1e293b", outline: "none", fontFamily: showPass ? "inherit" : "monospace", letterSpacing: showPass ? "normal" : "2px" }} 
          />
          <button 
            onClick={() => setShowPass(!showPass)} 
            style={{ marginTop: "8px", background: "#eef4ff", border: "none", padding: "8px 12px", borderRadius: "8px", cursor: "pointer", color: "#2563eb", fontSize: "13px", fontWeight: 600 }}
          >
            Show / Hide Password
          </button>
        </div>

        <div style={{ display: "grid", gap: "12px", marginTop: "24px" }}>
          {user.role === 'admin' && (
            <button onClick={() => navigate('/admin')} style={{ width: "100%", padding: "13px", border: "none", borderRadius: "10px", background: "#1e293b", color: "#fff", fontWeight: "bold", fontSize: "16px", cursor: "pointer" }}>
              Go to Admin Dashboard
            </button>
          )}
          <button onClick={handleLogout} style={{ width: "100%", padding: "13px", border: "none", borderRadius: "10px", background: "#ef4444", color: "#fff", fontWeight: "bold", fontSize: "16px", cursor: "pointer" }}>
            Logout
          </button>
        </div>
      </div>
    </>
  );
}
