import React, { useEffect, useState, useRef } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ThumbsUp, ThumbsDown, Share, Bookmark, Download, MoreHorizontal } from "lucide-react";
import Hls from 'hls.js';

export default function VideoPlayer({ user }: { user?: any }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [video, setVideo] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [restricted, setRestricted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const controlsTimeoutRef = React.useRef<any>(null);

  const resetControlsTimeout = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (!videoRef.current?.paused) setShowControls(false);
    }, 2000);
  };

  React.useEffect(() => {
    resetControlsTimeout();
    return () => {
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    };
  }, [isPaused]);
  const [userReaction, setUserReaction] = useState<'like' | 'dislike' | null>(null);
  const [viewCounted, setViewCounted] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [commentReactions, setCommentReactions] = useState<Record<number, string>>({});
  const [newComment, setNewComment] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (!user) {
      const watched = localStorage.getItem("watched_video_id");
      if (watched && watched !== id) {
        setRestricted(true);
        setLoading(false);
        return;
      } else if (id) {
        localStorage.setItem("watched_video_id", id);
      }
    }
    const token = localStorage.getItem("token");
    const headers: Record<string, string> = {};
    if (token) headers["Authorization"] = `Bearer ${token}`;
    
    
    
    const fetchComments = () => {
      fetch(`/api/videos/${id}/comments`)
        .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
        .then(data => {
           if (data.comments) setComments(data.comments);
        })
        .catch(console.error);
    };

    const fetchCommentReactions = () => {
      const token = localStorage.getItem('token');
      if (!token) return;
      fetch(`/api/videos/${id}/comments/reactions`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
      .then(data => {
        if (data.reactions) setCommentReactions(data.reactions);
      })
      .catch(console.error);
    };

    fetchComments();

    fetch(`/api/videos/${id}`, { headers })
      .then(async res => {
        if (!res.ok) return {};
        const text = await res.text();
        try {
          return JSON.parse(text);
        } catch(e) {
          return {};
        }
      })
      .then(data => {
        if (data.video) {
            setVideo(data.video);
            if (data.video.userReaction) {
                setUserReaction(data.video.userReaction);
            }
        }
      })
      .finally(() => setLoading(false));
  }, [id, user]);

  useEffect(() => {
    if (video && videoRef.current) {
      if (video.videoUrl.endsWith('.m3u8')) {
        if (Hls.isSupported()) {
          const hls = new Hls();
          hls.loadSource(video.videoUrl);
          hls.attachMedia(videoRef.current);
        } else if (videoRef.current.canPlayType('application/vnd.apple.mpegurl')) {
          videoRef.current.src = video.videoUrl;
        }
      } else {
        videoRef.current.src = video.videoUrl;
      }
    }
  }, [video?.videoUrl]);


  
  
  const handleCommentReaction = async (commentId: number, type: 'like' | 'dislike') => {
    if (!user) {
      alert("Please login to react to comments.");
      return;
    }
    const currentReaction = commentReactions[commentId];
    const newType = currentReaction === type ? null : type;
    
    // Optimistic UI update
    setCommentReactions(prev => ({ ...prev, [commentId]: newType || '' }));
    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        let newLikes = c.likes;
        if (currentReaction === 'like' && newType !== 'like') newLikes--;
        else if (currentReaction !== 'like' && newType === 'like') newLikes++;
        return { ...c, likes: newLikes };
      }
      return c;
    }));

    try {
      const token = localStorage.getItem('token');
      await fetch(`/api/videos/${id}/comments/${commentId}/react`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ type: newType })
      });
    } catch (error) {
      console.error(error);
    }
  };


  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert("Please login to comment");
      return;
    }
    if (!newComment.trim()) return;

    const token = localStorage.getItem("token");
    fetch(`/api/videos/${id}/comments`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ text: newComment })
    })
    .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
    .then(data => {
      if (data.success) {
        setNewComment('');
        // fetch comments again
        fetch(`/api/videos/${id}/comments`)
          .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
          .then(data => {
             if (data.comments) setComments(data.comments);
          });
      }
    })
    .catch(console.error);
  };

  const handleTimeUpdate = () => {
    if (videoRef.current && id) {
      try {
        const hist = JSON.parse(localStorage.getItem('dv_history') || '{}');
        hist[id] = {
          time: videoRef.current.currentTime,
          percent: (videoRef.current.currentTime / videoRef.current.duration) * 100,
          updated: Date.now()
        };
        localStorage.setItem('dv_history', JSON.stringify(hist));
      } catch (e) {}
    }
    if (videoRef.current && !viewCounted && video) {
      if (videoRef.current.currentTime > 30) {
        setViewCounted(true);
        fetch(`/api/videos/${id}/view`, { method: "POST" })
          .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
          .then(data => {
            if (data.success) {
               setVideo((v: any) => ({ ...v, views: data.views }));
            }
          })
          .catch(console.error);
      }
    }
  };

  const handleLike = () => {
    if (!user) {
        alert("Please login to like this video.");
        return;
    }
    const newReaction = userReaction === 'like' ? null : 'like';
    setUserReaction(newReaction);
    
    const token = localStorage.getItem("token");
    fetch(`/api/videos/${id}/react`, { 
        method: "POST", 
        headers: { 
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ type: newReaction }) 
    })
    .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
    .then(data => {
        if (data.likes !== undefined) {
            setVideo((v: any) => ({ ...v, likes: data.likes }));
            setUserReaction(data.userReaction);
        }
    });
  };

  const handleDislike = () => {
    if (!user) {
        alert("Please login to dislike this video.");
        return;
    }
    const newReaction = userReaction === 'dislike' ? null : 'dislike';
    setUserReaction(newReaction);
    
    const token = localStorage.getItem("token");
    fetch(`/api/videos/${id}/react`, { 
        method: "POST", 
        headers: { 
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ type: newReaction }) 
    })
    .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
    .then(data => {
        if (data.likes !== undefined) {
            setVideo((v: any) => ({ ...v, likes: data.likes }));
            setUserReaction(data.userReaction);
        }
    });
  };

  const handleShare = () => {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({
        title: video?.title || 'Watch this video',
        url: url
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(url);
      alert("Link copied to clipboard!");
    }
  };

  const [isFav, setIsFav] = useState(false);
  
  useEffect(() => {
    if (id) {
      try {
        const favs = JSON.parse(localStorage.getItem('dv_favs') || '[]');
        setIsFav(favs.includes(Number(id)));
      } catch (e) {}
    }
  }, [id]);

  const handleSave = () => {
    if (id) {
      try {
        let favs = JSON.parse(localStorage.getItem('dv_favs') || '[]');
        if (favs.includes(Number(id))) {
          favs = favs.filter((x: number) => x !== Number(id));
          setIsFav(false);
        } else {
          favs.push(Number(id));
          setIsFav(true);
        }
        localStorage.setItem('dv_favs', JSON.stringify(favs));
        alert(isFav ? "Removed from Library" : "Saved to Library");
        return;
      } catch(e) {}
    }
    if (!user) {
      if (window.confirm("Please login to save this video.")) {
        navigate("/login");
      }
      return;
    }
    alert("Video saved!");
  };

  if (loading) return <div style={{padding: '30px', textAlign: 'center', fontSize: '12px'}}>Loading video...</div>;
  if (restricted) return (
    <div style={{padding: '40px 20px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px'}}>
      <h2 style={{fontSize: '20px', fontWeight: 'bold'}}>Watch Limit Reached</h2>
      <p style={{color: 'var(--muted)', fontSize: '14px', maxWidth: '300px'}}>You have already watched 1 free video. Please login or sign up to continue watching unlimited videos.</p>
      <Link to="/login" className="pill-btn primary" style={{textDecoration: 'none'}}>Login / Sign Up</Link>
    </div>
  );
  
  if (!video) return <div style={{padding: '30px', textAlign: 'center', fontSize: '12px'}}>Video not found.</div>;

  return (
    <div style={{display: 'flex', flexDirection: 'column', gap: '16px'}}>
      
      <div style={{background: '#000', borderRadius: '15px', overflow: 'hidden', aspectRatio: '16/9', position: 'relative'}}
           onMouseMove={resetControlsTimeout}
           onMouseLeave={() => { if (!isPaused) setShowControls(false); }}
           onClick={() => {
             resetControlsTimeout();
             if (videoRef.current) {
               if (isPaused) {
                 videoRef.current.play();
                 setIsPaused(false);
               } else {
                 videoRef.current.pause();
                 setIsPaused(true);
               }
             }
           }}
      >
        <video 
          ref={videoRef}
          autoPlay 
          onTimeUpdate={handleTimeUpdate}
          onPlay={() => setIsPaused(false)}
          onPause={() => setIsPaused(true)}
          style={{width: '100%', height: '100%', objectFit: 'contain'}}
        />
        
        <div className="custom-video-controls" style={{
          position: 'absolute',
          inset: 0,
          opacity: showControls || isPaused ? 1 : 0,
          transition: 'opacity 0.3s',
          pointerEvents: showControls || isPaused ? 'auto' : 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 'clamp(28px, 8vw, 105px)',
          background: isPaused ? 'rgba(0,0,0,0.3)' : 'transparent',
        }}>
          <button className="control-btn previous" aria-label="Previous video" onClick={(e) => { e.stopPropagation(); /* TODO: previous logic */ }}>
            <svg viewBox="0 0 64 64" aria-hidden="true">
              <rect x="7" y="14" width="6" height="36" rx="3" fill="#8A8A8D"/>
              <path d="M49.5 14.7v34.6c0 1.7-1.9 2.7-3.3 1.8L18.9 33.8a2.15 2.15 0 0 1 0-3.6l27.3-17.3c1.4-.9 3.3.1 3.3 1.8Z" fill="#8A8A8D"/>
            </svg>
          </button>

          <button className="control-btn play-pause" aria-label={isPaused ? "Play video" : "Pause video"} onClick={(e) => {
            e.stopPropagation();
            if (videoRef.current) {
              if (isPaused) {
                videoRef.current.play();
                setIsPaused(false);
              } else {
                videoRef.current.pause();
                setIsPaused(true);
              }
            }
          }}>
            {isPaused ? (
              <svg viewBox="0 0 64 64" aria-hidden="true">
                <path d="M21 11.5 51 30.2a2.1 2.1 0 0 1 0 3.6L21 52.5c-1.5.9-3.4-.1-3.4-1.8V13.3c0-1.7 1.9-2.7 3.4-1.8Z" fill="#FFFFFF"/>
              </svg>
            ) : (
              <svg viewBox="0 0 64 64" aria-hidden="true">
                <rect x="13" y="7" width="14" height="50" rx="5" fill="#FFFFFF"/>
                <rect x="37" y="7" width="14" height="50" rx="5" fill="#FFFFFF"/>
              </svg>
            )}
          </button>

          <button className="control-btn next" aria-label="Next video" onClick={(e) => { e.stopPropagation(); /* TODO: next logic */ }}>
            <svg viewBox="0 0 64 64" aria-hidden="true">
              <path d="M14.5 14.7v34.6c0 1.7 1.9 2.7 3.3 1.8l27.3-17.3a2.15 2.15 0 0 0 0-3.6L17.8 12.9c-1.4-.9-3.3.1-3.3 1.8Z" fill="#FFFFFF"/>
              <rect x="51" y="14" width="6" height="36" rx="3" fill="#FFFFFF"/>
            </svg>
          </button>

<button className="control-btn fullscreen" aria-label="Fullscreen" onClick={(e) => {
            e.stopPropagation();
            const el = videoRef.current?.parentElement as any;
            if (el) {
              const isFullscreen = document.fullscreenElement || (document as any).webkitFullscreenElement;
              if (isFullscreen) {
                if (document.exitFullscreen) {
                  document.exitFullscreen();
                } else if ((document as any).webkitExitFullscreen) {
                  (document as any).webkitExitFullscreen();
                }
                if (window.screen && window.screen.orientation && window.screen.orientation.unlock) {
                  window.screen.orientation.unlock();
                }
              } else {
                const reqFs = el.requestFullscreen || el.webkitRequestFullscreen || el.mozRequestFullScreen || el.msRequestFullscreen;
                if (reqFs) {
                  const p = reqFs.call(el);
                  if (p && p.then) {
                    p.then(() => {
                      if (window.screen && window.screen.orientation && window.screen.orientation.lock) {
                        window.screen.orientation.lock('landscape').catch(err => console.log(err));
                      }
                    }).catch((e: any) => console.error(e));
                  } else {
                    // For browsers that don't return a promise (like Safari)
                    if (window.screen && window.screen.orientation && window.screen.orientation.lock) {
                      window.screen.orientation.lock('landscape').catch(err => console.log(err));
                    }
                  }
                }
              }
            }
          }} style={{ position: 'absolute', bottom: '16px', right: '16px', width: '40px', height: '40px', zIndex: 10 }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width: '20px', height: '20px'}}>
              <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
            </svg>
          </button>
        </div>


      </div>
  
      
      <div className="video-body" style={{padding: 0}}>
        <h1 style={{fontSize: '16px', fontWeight: 800, marginBottom: '6px'}}>{video.title}</h1>
        <p style={{fontSize: '10px', color: 'var(--muted)', marginBottom: '12px'}}>
          {video.views} views • {new Date(video.createdAt).toLocaleDateString()}
        </p>
        
        <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', margin: '8px 0', alignItems: 'center', WebkitOverflowScrolling: 'touch' }} className="hide-scrollbar">
          <div style={{ display: 'flex', alignItems: 'center', background: '#272727', color: '#fff', borderRadius: '999px', height: '36px', flexShrink: 0 }}>
            <button onClick={handleLike} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'transparent', border: 'none', color: userReaction === 'like' ? 'var(--brand)' : '#fff', padding: '0 12px 0 16px', height: '100%', fontSize: '14px', fontWeight: 600, borderRight: '1px solid rgba(255,255,255,0.2)', borderTopLeftRadius: '999px', borderBottomLeftRadius: '999px', cursor: 'pointer' }}>
              <ThumbsUp width={18} fill={userReaction === 'like' ? 'currentColor' : 'none'} /> {video.likes || 0}
            </button>
            <button onClick={handleDislike} style={{ display: 'flex', alignItems: 'center', background: 'transparent', border: 'none', color: userReaction === 'dislike' ? 'var(--brand)' : '#fff', padding: '0 16px 0 12px', height: '100%', borderTopRightRadius: '999px', borderBottomRightRadius: '999px', cursor: 'pointer' }}>
              <ThumbsDown width={18} fill={userReaction === 'dislike' ? 'currentColor' : 'none'} />
            </button>
          </div>
          
          <button onClick={handleShare} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#272727', color: '#fff', border: 'none', borderRadius: '999px', padding: '0 16px', height: '36px', fontSize: '14px', fontWeight: 600, flexShrink: 0, cursor: 'pointer' }}>
            <Share width={18} /> Share
          </button>
          
          <button onClick={handleSave} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#272727', color: '#fff', border: 'none', borderRadius: '999px', padding: '0 16px', height: '36px', fontSize: '14px', fontWeight: 600, flexShrink: 0, cursor: 'pointer' }}>
            <Bookmark width={18} fill={isFav ? "white" : "none"} /> {isFav ? "Saved" : "Save"}
          </button>
          
          <button style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#272727', color: '#fff', border: 'none', borderRadius: '999px', padding: '0 16px', height: '36px', fontSize: '14px', fontWeight: 600, flexShrink: 0, cursor: 'pointer' }}>
            <Download width={18} /> Download
          </button>
          
          <button style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#272727', color: '#fff', border: 'none', borderRadius: '50%', width: '36px', height: '36px', flexShrink: 0, cursor: 'pointer' }}>
            <MoreHorizontal width={18} />
          </button>
        </div>
        <style>{`.hide-scrollbar::-webkit-scrollbar { display: none; } .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }`}</style>
        <div style={{background: '#fff', borderRadius: '12px', padding: '12px', marginTop: '16px', border: '1px solid var(--line)', fontSize: '11px', color: 'var(--ink)'}}>
          <b style={{display: 'block', marginBottom: '4px'}}>Description</b>
          {video.description || "No description provided."}
        </div>

        <div style={{marginTop: '24px'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '16px'}}>
            <h3 style={{fontSize: '18px', fontWeight: 'bold'}}>{comments.length} Comments</h3>
            <span style={{fontSize: '14px', color: 'var(--muted)', display: 'flex', alignItems: 'center', gap: '4px'}}>Sort by</span>
          </div>

          <form onSubmit={handleCommentSubmit} style={{display: 'flex', gap: '12px', marginBottom: '24px'}}>
            <div style={{width: '40px', height: '40px', borderRadius: '50%', background: 'var(--brand)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', flexShrink: 0}}>
              {user ? (user.displayName?.[0] || user.email?.[0] || 'U').toUpperCase() : 'U'}
            </div>
            <div style={{flex: 1, display: 'flex', flexDirection: 'column'}}>
               <input 
                 type="text" 
                 placeholder="Add a comment..." 
                 value={newComment}
                 onChange={e => setNewComment(e.target.value)}
                 style={{border: 'none', borderBottom: '1px solid var(--line)', background: 'transparent', padding: '8px 0', color: 'var(--text)', outline: 'none', fontSize: '14px'}}
               />
               {newComment && (
                 <div style={{display: 'flex', justifyContent: 'flex-end', gap: '8px', marginTop: '8px'}}>
                   <button type="button" onClick={() => setNewComment('')} style={{background: 'transparent', border: 'none', color: 'var(--text)', padding: '8px 12px', borderRadius: '20px', cursor: 'pointer', fontWeight: 600}}>Cancel</button>
                   <button type="submit" style={{background: 'var(--brand)', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '20px', cursor: 'pointer', fontWeight: 600}}>Comment</button>
                 </div>
               )}
            </div>
          </form>

          <div style={{display: 'flex', flexDirection: 'column', gap: '20px'}}>
            {comments.map((c, i) => (
              <div key={i} style={{display: 'flex', gap: '12px'}}>
                <div style={{width: '40px', height: '40px', borderRadius: '50%', background: '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink)', fontWeight: 'bold', flexShrink: 0}}>
                  {(c.user?.displayName?.[0] || c.user?.email?.[0] || 'U').toUpperCase()}
                </div>
                <div style={{flex: 1}}>
                  <div style={{display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px'}}>
                    <span style={{fontWeight: 600, fontSize: '14px'}}>@{c.user?.displayName || c.user?.email?.split('@')[0] || 'User'}</span>
                    <span style={{color: 'var(--muted)', fontSize: '12px'}}>
                      {(() => {
                        const days = Math.floor((new Date().getTime() - new Date(c.createdAt).getTime()) / (1000 * 3600 * 24));
                        return days === 0 ? 'Today' : `${days} days ago`;
                      })()}
                    </span>
                  </div>
                  <p style={{fontSize: '14px', lineHeight: 1.4, margin: '0 0 8px 0'}}>{c.text}</p>
                  <div style={{display: 'flex', alignItems: 'center', gap: '16px'}}>
                    <button onClick={() => handleCommentReaction(c.id, 'like')} style={{background: 'none', border: 'none', color: commentReactions[c.id] === 'like' ? 'var(--brand)' : 'var(--text)', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer', padding: 0}}>
                      <ThumbsUp width={16} fill={commentReactions[c.id] === 'like' ? 'currentColor' : 'none'} /> <span style={{fontSize: '12px'}}>{c.likes}</span>
                    </button>
                    <button onClick={() => handleCommentReaction(c.id, 'dislike')} style={{background: 'none', border: 'none', color: commentReactions[c.id] === 'dislike' ? 'var(--brand)' : 'var(--text)', display: 'flex', alignItems: 'center', cursor: 'pointer', padding: 0}}>
                      <ThumbsDown width={16} fill={commentReactions[c.id] === 'dislike' ? 'currentColor' : 'none'} />
                    </button>
                    <button style={{background: 'none', border: 'none', color: 'var(--text)', fontSize: '12px', fontWeight: 600, cursor: 'pointer', padding: 0}}>
                      Reply
                    </button>
                  </div>
                </div>
                <button style={{background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', padding: 0, height: '24px'}}>
                   <MoreHorizontal width={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
