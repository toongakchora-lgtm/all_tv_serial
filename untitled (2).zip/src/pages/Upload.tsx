import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Upload as UploadIcon, FileVideo } from "lucide-react";

export default function Upload({ user }: { user: any }) {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("entertainment");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  if (!user) return <div style={{padding: '30px', textAlign: 'center', fontSize: '14px', color: 'var(--muted)', marginTop: '60px'}}>Please login to upload videos.</div>;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError("Please select a video file");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("token");
      const chunkSize = 10 * 1024 * 1024; // 10MB chunks
      const totalChunks = Math.ceil(file.size / chunkSize);
      const uploadId = crypto.randomUUID();

      for (let i = 0; i < totalChunks; i++) {
        const start = i * chunkSize;
        const end = Math.min(start + chunkSize, file.size);
        const chunk = file.slice(start, end);

        const formData = new FormData();
        formData.append("chunk", chunk);
        formData.append("uploadId", uploadId);
        formData.append("chunkIndex", i.toString());
        formData.append("totalChunks", totalChunks.toString());
        if (i === totalChunks - 1) {
          formData.append("title", title);
          formData.append("description", description);
          formData.append("category", category);
          formData.append("originalName", file.name);
        }

        const res = await fetch("/api/videos/upload-chunk", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
          body: formData,
        });

        if (!res.ok) {
          const text = await res.text();
          let errStr = "Upload failed";
          try { errStr = JSON.parse(text).error || errStr; } catch(e) {}
          throw new Error(errStr);
        }
      }
      
      alert("Video uploaded successfully and is pending admin approval!");
      navigate("/");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container mt-16">
      <h1 style={{fontFamily: '"Playfair Display", serif', fontSize: '28px', fontWeight: 900, textAlign: 'center', marginBottom: '10px'}}>Upload Video</h1>
      
      {error && <div style={{background: 'rgba(255, 63, 116, 0.1)', color: '#ff3f74', padding: '10px', borderRadius: '10px', fontSize: '12px', border: '1px solid rgba(255, 63, 116, 0.3)'}}>{error}</div>}
      
      <form onSubmit={handleSubmit} style={{display: 'flex', flexDirection: 'column', gap: '12px'}}>
        
        <div 
          onClick={() => fileInputRef.current?.click()}
          style={{
            border: `2px dashed ${file ? 'var(--green)' : 'var(--line)'}`, 
            borderRadius: '15px', 
            padding: '30px', 
            textAlign: 'center', 
            cursor: 'pointer',
            background: file ? 'rgba(0, 223, 143, 0.05)' : '#0d120f',
            transition: '0.2s'
          }}
        >
          <input 
            type="file" 
            accept="video/*" 
            style={{display: 'none'}}
            ref={fileInputRef}
            onChange={e => setFile(e.target.files?.[0] || null)}
          />
          
          {file ? (
            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
              <FileVideo size={36} color="var(--green)" style={{marginBottom: '10px'}} />
              <p style={{fontWeight: 700, fontSize: '13px', color: 'var(--white)'}}>{file.name}</p>
              <p style={{fontSize: '11px', color: 'var(--green)', marginTop: '4px'}}>{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
            </div>
          ) : (
            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
              <UploadIcon size={36} color="var(--muted)" style={{marginBottom: '10px'}} />
              <p style={{fontWeight: 700, fontSize: '13px', color: 'var(--white)'}}>Click to select video</p>
              <p style={{fontSize: '11px', color: 'var(--muted)', marginTop: '4px'}}>MP4, WebM, or OGG</p>
            </div>
          )}
        </div>

        <input 
          type="text" 
          value={title} 
          onChange={e => setTitle(e.target.value)} 
          required 
          className="auth-input" 
          placeholder="Video Title" 
        />
        
        <textarea 
          value={description} 
          onChange={e => setDescription(e.target.value)} 
          rows={3} 
          className="auth-input" 
          placeholder="Description" 
          style={{resize: 'none', fontFamily: 'inherit'}}
        />

        <select 
          value={category} 
          onChange={e => setCategory(e.target.value)} 
          className="auth-input" 
        >
          <option value="entertainment" style={{background: '#0d120f'}}>Entertainment</option>
          <option value="education" style={{background: '#0d120f'}}>Education</option>
          <option value="gaming" style={{background: '#0d120f'}}>Gaming</option>
          <option value="music" style={{background: '#0d120f'}}>Music</option>
          <option value="news" style={{background: '#0d120f'}}>News</option>
          <option value="motivation" style={{background: '#0d120f'}}>Motivation</option>
        </select>

        <button 
          type="submit" 
          disabled={loading || !file} 
          className="auth-btn"
          style={{opacity: (loading || !file) ? 0.5 : 1}}
        >
          {loading ? "Uploading..." : "Upload Video"}
        </button>
      </form>
    </div>
  );
}
