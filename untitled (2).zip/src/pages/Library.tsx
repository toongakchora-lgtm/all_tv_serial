import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";

export default function Library() {
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [favorites, setFavorites] = useState<number[]>([]);
  const [history, setHistory] = useState<Record<string, any>>({});

  useEffect(() => {
    try {
      const favs = JSON.parse(localStorage.getItem('dv_favs') || '[]');
      setFavorites(Array.isArray(favs) ? favs : []);
      
      const hist = JSON.parse(localStorage.getItem('dv_history') || '{}');
      setHistory(typeof hist === 'object' && hist !== null ? hist : {});
    } catch (e) {
      console.error(e);
    }

    fetch("/api/videos")
      .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
      .then(data => {
        if (data.videos) {
          setVideos(data.videos.filter((v: any) => v.status === "approved"));
        }
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)' }}>Loading...</div>;

  const favVideos = videos.filter(v => favorites.includes(v.id));
  const histVideos = videos.filter(v => history[v.id]);

  const renderSection = (title: string, items: any[], landscape = false) => {
    if (items.length === 0) return null;
    return (
      <section className="section" style={{ marginBottom: '30px' }}>
        <div className="section-head" style={{ display: 'flex', alignItems: 'end', justifyContent: 'space-between', marginBottom: '13px' }}>
          <div>
            <h2 style={{ margin: 0, fontSize: '21px', color: '#17233a', fontWeight: 800 }}>{title}</h2>
            <small style={{ color: 'var(--muted)' }}>{items.length} titles</small>
          </div>
          <Link to="/discover" className="icon-btn" style={{ textDecoration: 'none', fontSize: '14px', padding: '8px 12px' }}>View all</Link>
        </div>
        <div className="row" style={{ display: 'grid', gridAutoFlow: 'column', gridAutoColumns: landscape ? '82%' : '82%', gap: '12px', overflowX: 'auto', scrollSnapType: 'x mandatory', paddingBottom: '8px' }}>
          {items.map(item => {
            const isFav = favorites.includes(item.id);
            const p = Math.round(history[item.id]?.percent || 0);
            return (
              <Link to={`/video/${item.id}`} key={item.id} className={`card ${landscape ? 'card-landscape' : ''}`} style={{ scrollSnapAlign: 'start', position: 'relative', borderRadius: '16px', overflow: 'hidden', background: 'var(--panel)', border: '1px solid var(--line)', transition: '.2s', textDecoration: 'none', display: 'block', color: 'inherit', boxShadow: '0 8px 22px rgba(15, 23, 42, .06)' }}>
                <div className="card-poster" style={{ aspectRatio: '16/9', position: 'relative', background: '#1c1c28' }}>
                  <img src={item.thumbnailUrl || "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1100&q=80"} alt={item.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <span className="badge" style={{ position: 'absolute', left: '8px', top: '8px', padding: '5px 8px', borderRadius: '8px', background: 'rgba(0,0,0,.7)', fontSize: '11px', fontWeight: 800, color: '#fff', zIndex: 2 }}>16:9</span>
                  <button className={`fav ${isFav ? 'on' : ''}`} onClick={(e) => { e.preventDefault(); /* toggle not impl here to match simplicity */ }} style={{ position: 'absolute', right: '8px', top: '8px', width: '34px', height: '34px', borderRadius: '50%', border: '1px solid rgba(255,255,255,.7)', background: 'rgba(255,255,255,.92)', color: isFav ? '#2563eb' : '#1e3a8a', zIndex: 3, fontSize: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Heart width={18} fill={isFav ? "currentColor" : "none"} />
                  </button>
                  <div className="card-grad" style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg,rgba(5,5,8,.92),transparent 58%)' }}></div>
                </div>
                {p > 0 && (
                  <div className="progress" style={{ height: '4px', background: '#333344' }}>
                    <i style={{ display: 'block', height: '100%', width: `${p}%`, background: 'linear-gradient(90deg,var(--brand),#60a5fa)' }}></i>
                  </div>
                )}
                <div className="card-info" style={{ padding: '11px' }}>
                  <div className="card-title" style={{ fontWeight: 800, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontSize: '14px' }}>{item.title}</div>
                  <div className="meta" style={{ color: 'var(--muted)', fontSize: '12px', marginTop: '5px', display: 'flex', gap: '8px' }}>
                    <span>{item.category || 'Drama'}</span>
                    <span>★ {item.rating || 'New'}</span>
                    <span>{item.views || 0} views</span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>
    );
  };

  return (
    <>
      <div className="section-head" style={{ marginTop: '8px' }}>
        <div>
          <h2 style={{ margin: 0, fontSize: '21px', color: '#17233a', fontWeight: 800 }}>My Library</h2>
          <small style={{ color: 'var(--muted)' }}>Saved और watched content</small>
        </div>
      </div>
      
      {renderSection('My Favorites', favVideos)}
      {renderSection('Watch History', histVideos, true)}
      
      {!favVideos.length && !histVideos.length && (
        <div className="empty" style={{ border: '1px dashed var(--line)', borderRadius: '18px', padding: '38px 18px', textAlign: 'center', color: 'var(--muted)' }}>
          आपकी library अभी खाली है। किसी drama को favorite करें या देखना शुरू करें।
        </div>
      )}
    </>
  );
}
