import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

export default function Login({ setUser }: { setUser: any }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      let data: any = {};
      try {
        const text = await res.text();
        data = text ? JSON.parse(text) : {};
      } catch(e) {
        // do nothing
      }
      
      if (!res.ok) throw new Error(data.error || "Login failed");
      
      localStorage.setItem("token", data.token);
      setUser(data.user);
      navigate("/");
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="auth-container mt-16">
      <h1 style={{fontFamily: '"Playfair Display", serif', fontSize: '28px', fontWeight: 900, textAlign: 'center', marginBottom: '10px'}}>Welcome Back</h1>
      {error && <div style={{background: 'rgba(255, 63, 116, 0.1)', color: '#ff3f74', padding: '10px', borderRadius: '10px', fontSize: '12px', border: '1px solid rgba(255, 63, 116, 0.3)'}}>{error}</div>}
      <form onSubmit={handleSubmit} style={{display: 'flex', flexDirection: 'column', gap: '12px'}}>
        <input 
          type="text" 
          value={email} 
          onChange={e => setEmail(e.target.value)} 
          required 
          className="auth-input" 
          placeholder="Email or Username" 
        />
        <input 
          type="password" 
          value={password} 
          onChange={e => setPassword(e.target.value)} 
          required 
          className="auth-input" 
          placeholder="Password" 
        />
        <button type="submit" className="auth-btn">Login</button>
      </form>
      <p style={{textAlign: 'center', fontSize: '13px', marginTop: '10px', color: 'var(--muted)'}}>
        Don't have an account? <Link to="/register" style={{color: 'var(--green)', fontWeight: 'bold', textDecoration: 'none'}}>Register</Link>
      </p>
    </div>
  );
}
