import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Play, Plus, Heart } from "lucide-react";

export default function Home({ siteName }: any) {
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeBanners, setActiveBanners] = useState<any[]>([]);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const [homeSections, setHomeSections] = useState<any[]>([]);

  useEffect(() => {
    const fetchVideos = () => {
      fetch("/api/videos")
        .then(async res => {
          if (!res.ok) return { videos: [] };
          const text = await res.text();
          try {
            return JSON.parse(text);
          } catch (e) {
            return { videos: [] };
          }
        })
        .then(data => {
          if (data.videos) {
            setVideos(data.videos.filter((v: any) => v.status === "approved"));
          }
        })
        .finally(() => setLoading(false));
    };
    
    fetchVideos();
    const interval = setInterval(fetchVideos, 3000);

    const fetchBanners = () => {
      fetch("/api/banners")
        .then(async res => {
          if (!res.ok) return {};
          try {
            return JSON.parse(await res.text());
          } catch (e) {
            return {};
          }
        })
        .then(data => {
          if (data.banners) {
            const active = data.banners.filter((b: any) => b.active);
            setActiveBanners(active);
          } else {
            setActiveBanners([]);
          }
        })
        .catch(() => {});
    };

    fetchBanners();
    const bannerInterval = setInterval(fetchBanners, 3000);

    const fetchSections = () => {
      fetch("/api/settings")
        .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
        .then(data => {
          if (data.homepage_sections) {
            try {
              setHomeSections(JSON.parse(data.homepage_sections));
            } catch(e) {}
          } else {
            setHomeSections([
              { id: '1', title: 'Continue Watching', type: 'continue_watching', landscape: true },
              { id: '2', title: 'Short Dramas', type: 'category', category: 'Short Dramas', landscape: false },
              { id: '3', title: 'Movies & Web Series', type: 'category', category: 'Movies', landscape: true },
              { id: '4', title: 'Trending Now', type: 'trending', landscape: false }
            ]);
          }
        })
        .catch(console.error);
    };
    fetchSections();


    return () => {
      clearInterval(interval);
      clearInterval(bannerInterval);
    };
  }, []);


  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentBannerIndex(prev => (prev + 1) % activeBanners.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [activeBanners.length]);

  const heroVideo = videos.length > 0 ? videos[0] : null;


  const renderSection = (title: string, items: any[], landscape = false) => {
    if (!items.length) return null;
    return (
      <section className="section">
        <div className="section-head">
          <div>
            <h2>{title}</h2>
            <small>{items.length} titles</small>
          </div>
          <Link to="/discover" className="icon-btn" style={{ padding: '6px 12px', fontSize: '12px' }}>View all</Link>
        </div>
        <div className="row">
          {items.map(video => (
            <Link to={`/video/${video.id}`} key={video.id} className={`card ${landscape ? 'card-landscape' : ''}`}>
              <div className="card-poster">
                <img src={video.thumbnailUrl || "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1100&q=80"} alt={video.title} />
                <span className="badge">16:9</span>
                <button className="fav" onClick={(e) => { e.preventDefault(); }}>
                  <Heart width={18} />
                </button>
                <div className="card-grad"></div>
              </div>
              <div className="card-info">
                <div className="card-title">{video.title}</div>
                <div className="meta">
                  <span>{video.category || 'Drama'}</span>
                  <span>★ {video.rating || 'New'}</span>
                  <span>{video.views || 0} views</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    );
  };

  return (
    <>
      <div className="welcome-strip">
        <b>Welcome to {siteName || "SK Stream"}</b>
        <span>Study breaks ke liye short dramas aur videos</span>
      </div>

            {activeBanners.length > 0 && (
        <section className="hero" style={{ overflow: 'hidden', position: 'relative' }}>
          <div style={{
            display: 'flex',
            transition: 'transform 0.5s ease-in-out',
            transform: `translateX(-${currentBannerIndex * 100}%)`,
            width: '100%',
            height: '100%'
          }}>
            {activeBanners.map((b, i) => (
              <div key={b.id} style={{ minWidth: '100%', position: 'relative', height: '100%' }}>
                <img src={b.imageUrl} alt={b.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div className="hero-content">
                  <span className="tag">#1 Trending</span>
                  <h1>{b.title}</h1>
                  <p>Watch top trending content and short dramas right now on {siteName || "SK Stream"}.</p>
                  <div className="hero-actions">
                    <Link to="/discover" className="btn primary">
                      <Play width={16} fill="currentColor" /> Watch Now
                    </Link>
                    <button className="btn">
                      <Plus width={16} /> My List
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div style={{ position: 'absolute', bottom: '10px', left: '0', right: '0', display: 'flex', justifyContent: 'center', gap: '6px' }}>
            {activeBanners.map((_, i) => (
              <div key={i} style={{ width: i === currentBannerIndex ? '20px' : '6px', height: '6px', borderRadius: '3px', background: i === currentBannerIndex ? 'var(--brand)' : 'rgba(255,255,255,0.5)', transition: 'all 0.3s ease' }}></div>
            ))}
          </div>
        </section>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)' }}>Loading...</div>
      ) : videos.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)' }}>No videos found.</div>
      ) : (
        
        <>
          {homeSections.map(sec => {
            let items: any[] = [];
            if (sec.type === 'continue_watching') {
              items = videos.slice(1, 4); // Dummy for now
            } else if (sec.type === 'trending') {
              items = [...videos].sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 6);
            } else if (sec.type === 'category') {
              items = videos.filter(v => v.category === sec.category);
            }
            return <React.Fragment key={sec.id}>{renderSection(sec.title, items, sec.landscape)}</React.Fragment>;
          })}
        </>

      )}
    </>
  );
}

