import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Heart, Search as SearchIcon } from "lucide-react";

export default function Search() {
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  useEffect(() => {
    fetch("/api/videos")
      .then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })
      .then(data => {
        if (data.videos) {
          setVideos(data.videos.filter((v: any) => v.status === "approved"));
        }
      })
      .finally(() => setLoading(false));
  }, []);

  const val = query.toLowerCase().trim();
  const items = val 
    ? videos.filter(x => (x.title + ' ' + (x.category || 'Drama') + ' ' + (x.description || '')).toLowerCase().includes(val))
    : videos;

  if (loading) return <div style={{ textAlign: 'center', padding: '40px', color: 'var(--muted)' }}>Loading...</div>;

  return (
    <>
      <div className="section-head" style={{ marginTop: '8px' }}>
        <div>
          <h2>Search</h2>
          <small>Drama, genre और story खोजें</small>
        </div>
      </div>
      
      <div className="searchbox" style={{ display: 'flex', gap: '8px', background: '#fff', border: '1px solid var(--line)', padding: '9px', borderRadius: '16px', margin: '4px 0 18px', boxShadow: '0 6px 18px rgba(15,23,42,.05)' }}>
        <span style={{ padding: '7px', display: 'flex', alignItems: 'center', color: 'var(--muted)' }}>
          <SearchIcon width={20} />
        </span>
        <input 
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
          placeholder="Search dramas..." 
          style={{ flex: 1, minWidth: 0, background: 'transparent', color: 'var(--text)', border: 0, outline: 0, padding: '7px', fontSize: '16px' }}
        />
      </div>
      
      {items.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '16px' }}>
          {items.map(video => (
            <Link to={`/video/${video.id}`} key={video.id} className="card card-landscape" style={{ textDecoration: 'none', color: 'inherit', display: 'block', background: 'var(--panel)', border: '1px solid var(--line)', borderRadius: '16px', overflow: 'hidden' }}>
              <div className="card-poster" style={{ aspectRatio: '16/9', position: 'relative', background: '#1c1c28' }}>
                <img src={video.thumbnailUrl || "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1100&q=80"} alt={video.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <span className="badge" style={{ position: 'absolute', left: '8px', top: '8px', padding: '5px 8px', borderRadius: '8px', background: 'rgba(0,0,0,.7)', fontSize: '11px', fontWeight: 800, color: '#fff', zIndex: 2 }}>16:9</span>
                <button className="fav" onClick={(e) => { e.preventDefault(); }} style={{ position: 'absolute', right: '8px', top: '8px', width: '34px', height: '34px', borderRadius: '50%', border: '1px solid rgba(255,255,255,.7)', background: 'rgba(255,255,255,.92)', color: '#1e3a8a', zIndex: 3, fontSize: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Heart width={18} />
                </button>
                <div className="card-grad" style={{ position: 'absolute', inset: 0, background: 'linear-gradient(0deg,rgba(5,5,8,.92),transparent 58%)' }}></div>
              </div>
              <div className="card-info" style={{ padding: '11px' }}>
                <div className="card-title" style={{ fontWeight: 800, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontSize: '14px' }}>{video.title}</div>
                <div className="meta" style={{ color: 'var(--muted)', fontSize: '12px', marginTop: '5px', display: 'flex', gap: '8px' }}>
                  <span>{video.category || 'Drama'}</span>
                  <span>★ {video.rating || 'New'}</span>
                  <span>{video.views || 0} views</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div style={{ border: '1px dashed var(--line)', borderRadius: '18px', padding: '38px 18px', textAlign: 'center', color: 'var(--muted)' }}>
          कोई drama नहीं मिला
        </div>
      )}
    </>
  );
}
