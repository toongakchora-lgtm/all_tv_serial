const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');

if (!css.includes('.custom-video-controls')) {
  css += `
.custom-video-controls {
  width: 100%;
  height: 100%;
}
.control-btn {
  border: none;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(20,16,12,0.50);
  box-shadow: inset 0 0 0 1px rgba(255,255,255,0.03), 0 2px 4px rgba(0,0,0,0.28);
  backdrop-filter: blur(2px);
  -webkit-backdrop-filter: blur(2px);
  cursor: pointer;
  flex: 0 0 auto;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.15s ease, background 0.15s ease;
}
.control-btn:active {
  transform: scale(0.95);
}
.control-btn:hover {
  background: rgba(20,16,12,0.60);
}
.previous,
.next {
  width: clamp(50px, 10vw, 80px);
  height: clamp(50px, 10vw, 80px);
}
.play-pause {
  width: clamp(60px, 12vw, 96px);
  height: clamp(60px, 12vw, 96px);
}
.control-btn svg {
  display: block;
  filter: drop-shadow(0 2px 2px rgba(0,0,0,0.85));
}
.previous svg,
.next svg {
  width: 46%;
  height: 46%;
}
.play-pause svg {
  width: 45%;
  height: 45%;
}
@media(max-width: 480px) {
  .previous,
  .next {
    width: 48px;
    height: 48px;
  }
  .play-pause {
    width: 60px;
    height: 60px;
  }
}
`;
  fs.writeFileSync('src/index.css', css);
}
