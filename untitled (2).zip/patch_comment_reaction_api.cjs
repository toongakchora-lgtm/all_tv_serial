const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const importReplacement = 'import { users, videos, banners, reactions, settings, comments, comment_reactions } from "./src/db/schema.js";';
code = code.replace(
  'import { users, videos, banners, reactions, settings, comments } from "./src/db/schema.js";',
  importReplacement
);

const apiString = `
  app.post("/api/videos/:id/comments/:commentId/react", authenticateToken, express.json(), async (req: any, res: any) => {
    try {
      const commentId = parseInt(req.params.commentId);
      const { type } = req.body; // 'like', 'dislike', or null
      
      const userId = req.user.id;

      const commentResult = await db.select().from(comments).where(eq(comments.id, commentId));
      if (commentResult.length === 0) {
        return res.status(404).json({ error: "Comment not found" });
      }

      // Find existing reaction
      const existingReaction = await db.select()
        .from(comment_reactions)
        .where(and(
          eq(comment_reactions.commentId, commentId),
          eq(comment_reactions.userId, userId)
        ));

      if (existingReaction.length > 0) {
        if (type === null) {
          // Remove reaction
          await db.delete(comment_reactions).where(eq(comment_reactions.id, existingReaction[0].id));
          if (existingReaction[0].type === 'like') {
            await db.update(comments).set({ likes: commentResult[0].likes - 1 }).where(eq(comments.id, commentId));
          }
        } else if (existingReaction[0].type !== type) {
          // Change reaction
          await db.update(comment_reactions).set({ type }).where(eq(comment_reactions.id, existingReaction[0].id));
          if (type === 'like') {
            await db.update(comments).set({ likes: commentResult[0].likes + 1 }).where(eq(comments.id, commentId));
          } else if (existingReaction[0].type === 'like') {
            await db.update(comments).set({ likes: commentResult[0].likes - 1 }).where(eq(comments.id, commentId));
          }
        }
      } else if (type !== null) {
        // Add new reaction
        await db.insert(comment_reactions).values({
          commentId,
          userId,
          type
        });
        if (type === 'like') {
          await db.update(comments).set({ likes: commentResult[0].likes + 1 }).where(eq(comments.id, commentId));
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to react to comment" });
    }
  });

  app.get("/api/videos/:id/comments/reactions", authenticateToken, async (req: any, res: any) => {
    try {
      const userId = req.user.id;
      const videoId = parseInt(req.params.id);
      
      // Get all comment reactions for this user on this video's comments
      // To do this simply, we fetch all comment reactions for this user, then filter in memory or join
      const userReactions = await db.select({
        commentId: comment_reactions.commentId,
        type: comment_reactions.type
      })
      .from(comment_reactions)
      .where(eq(comment_reactions.userId, userId));
      
      const reactionMap: Record<number, string> = {};
      userReactions.forEach(r => {
        reactionMap[r.commentId] = r.type;
      });

      res.json({ reactions: reactionMap });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch comment reactions" });
    }
  });
`;

if (!code.includes('/api/videos/:id/comments/:commentId/react')) {
  code = code.replace(
    'app.post("/api/videos/:id/react",',
    apiString + '\n\n  app.post("/api/videos/:id/react",'
  );
  fs.writeFileSync('server.ts', code);
}
