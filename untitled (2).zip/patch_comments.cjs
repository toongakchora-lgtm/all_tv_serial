const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf8');

const commentEndpoints = `
  app.get("/api/videos/:id/comments", async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      // Join comments with users to get displayName and email
      const commentsResult = await db.select({
        id: comments.id,
        videoId: comments.videoId,
        userId: comments.userId,
        text: comments.text,
        likes: comments.likes,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          displayName: users.displayName,
          email: users.email
        }
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.videoId, videoId))
      .orderBy(desc(comments.createdAt));

      res.json({ comments: commentsResult });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  app.post("/api/videos/:id/comments", authenticateToken, express.json(), async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.id;
      const { text } = req.body;

      if (!text || text.trim() === '') {
        return res.status(400).json({ error: "Comment text is required" });
      }

      await db.insert(comments).values({
        videoId,
        userId,
        text: text.trim()
      });

      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to add comment" });
    }
  });
`;

serverCode = serverCode.replace('  app.post("/api/videos/:id/react",', commentEndpoints + '\n  app.post("/api/videos/:id/react",');

fs.writeFileSync('server.ts', serverCode);
