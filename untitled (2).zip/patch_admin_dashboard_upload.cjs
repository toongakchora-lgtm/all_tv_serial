const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

if (!code.includes("import { storage } from '../firebase'")) {
  code = code.replace(
    "import { LogOut, Home, Play, Users, Settings, Plus, Search, Grid2X2, ImageIcon, IndianRupee, Menu } from 'lucide-react';",
    "import { LogOut, Home, Play, Users, Settings, Plus, Search, Grid2X2, ImageIcon, IndianRupee, Menu } from 'lucide-react';\nimport { storage } from '../firebase';\nimport { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';"
  );
}

// Rewrite handleSaveVideo to use Firebase Storage
const newHandleSaveVideo = `
  const handleSaveVideo = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    
    // Convert to proper status strings for backend
    const statusVal = formData.get("status") as string;
    let dbStatus = "approved";
    if (statusVal === "draft") dbStatus = "pending";
    if (statusVal === "off") dbStatus = "rejected";
    if (statusVal === "live") dbStatus = "approved";
    formData.set("status", dbStatus);
    const token = localStorage.getItem("token");
    
    const url = editingVideo ? \`/api/admin/videos/\${editingVideo.id}\` : "/api/admin/videos/add";
    const method = editingVideo ? "PUT" : "POST";
    
    try {
      setUploadProgress(0);
      const videoFile = formData.get("videoFile") as File;
      if (videoFile && videoFile.size > 0) {
        const videoRef = ref(storage, \`videos/\${Date.now()}-\${videoFile.name}\`);
        const uploadTask = uploadBytesResumable(videoRef, videoFile);
        
        await new Promise((resolve, reject) => {
          uploadTask.on('state_changed', 
            (snapshot) => {
              const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
              setUploadProgress(progress);
            }, 
            (error) => reject(error), 
            async () => {
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
              formData.set("video", downloadURL);
              resolve(true);
            }
          );
        });
      }
      formData.delete("videoFile");
      
      const posterFile = formData.get("posterFile") as File;
      if (posterFile && posterFile.size > 0) {
        setUploadProgress(0); // Reset for poster
        const posterRef = ref(storage, \`posters/\${Date.now()}-\${posterFile.name}\`);
        const uploadTask = uploadBytesResumable(posterRef, posterFile);
        
        await new Promise((resolve, reject) => {
          uploadTask.on('state_changed', 
            (snapshot) => {
              const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
              setUploadProgress(progress); // Assuming same progress bar
            }, 
            (error) => reject(error), 
            async () => {
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
              formData.set("poster", downloadURL);
              resolve(true);
            }
          );
        });
      }
      formData.delete("posterFile");
      
      // Convert FormData to JSON
      const jsonBody: Record<string, any> = {};
      formData.forEach((value, key) => {
        jsonBody[key] = value;
      });

      const res = await fetch(url, {
        method: method,
        headers: { 
          "Content-Type": "application/json",
          ...(token ? { Authorization: \`Bearer \${token}\` } : {})
        },
        body: JSON.stringify(jsonBody),
      });

      if (res.ok) {
        setEditingVideo(null);
        setUploadProgress(0);
        fetchVideos();
        // Trigger a fake re-render or notification to show real-time update
      } else {
        alert("Failed to save video");
      }
    } catch (e) {
      console.error(e);
      alert("Error saving video");
    }
  };
`;

code = code.replace(
  /const handleSaveVideo = async \(e: React\.FormEvent<HTMLFormElement>\) => \{[\s\S]*?catch \(e\) \{\s*console\.error\(e\);\s*alert\("Error saving video"\);\s*\}\s*\};/,
  newHandleSaveVideo
);

// We need to also modify addBanner to use Firebase Storage directly
const newAddBanner = `
  const addBanner = async () => {
    const val = newBannerTitle.trim() || "New Banner";
    if (newBannerImages.length === 0) {
      alert("Please select at least one image");
      return;
    }

    const checkAspectRatio = (file: any) => {
      return new Promise((resolve) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => {
          const ratio = img.width / img.height;
          if (ratio >= 1.7 && ratio <= 1.8) resolve(true);
          else resolve(false);
          URL.revokeObjectURL(url);
        };
        img.onerror = () => resolve(false);
        img.src = url;
      });
    };

    for (const img of newBannerImages) {
      const isValid = await checkAspectRatio(img);
      if (!isValid) {
        alert("Only 16:9 aspect ratio images are allowed.");
        return;
      }
    }

    const token = localStorage.getItem("token");
    try {
      const imageUrls: string[] = [];
      for (const img of newBannerImages) {
        const bannerRef = ref(storage, \`banners/\${Date.now()}-\${img.name}\`);
        const uploadTask = uploadBytesResumable(bannerRef, img);
        await new Promise((resolve, reject) => {
          uploadTask.on('state_changed', null, reject, async () => {
            const url = await getDownloadURL(uploadTask.snapshot.ref);
            imageUrls.push(url);
            resolve(true);
          });
        });
      }

      const res = await fetch("/api/admin/banners", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          Authorization: \`Bearer \${token}\` 
        },
        body: JSON.stringify({ title: val, imageUrls: imageUrls })
      });
      if (res.ok) {
        setNewBannerTitle("");
        setNewBannerImages([]);
        fetchBanners();
      } else {
        alert("Failed to upload banner");
      }
    } catch (e) {
      console.error(e);
      alert("Failed to save banner");
    }
  };
`;

code = code.replace(
  /const addBanner = async \(\) => \{[\s\S]*?alert\("Failed to upload banner"\);\s*\}\s*\} catch \(e\) \{\s*console\.error\(e\);\s*\}\s*\};/,
  newAddBanner
);

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
