const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes('import Discover from "./pages/Discover";')) {
  code = code.replace(
    'import Home from "./pages/Home";',
    'import Home from "./pages/Home";\nimport Discover from "./pages/Discover";'
  );
}

if (!code.includes('<Route path="/discover" element={<Discover />} />')) {
  code = code.replace(
    '<Route path="/" element={<Home siteName={siteName} />} />',
    '<Route path="/" element={<Home siteName={siteName} />} />\n          <Route path="/discover" element={<Discover />} />'
  );
}

fs.writeFileSync('src/App.tsx', code);
