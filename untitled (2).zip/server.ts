import express from "express";
import path from "path";
import multer from "multer";
import fs from "fs";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { v4 as uuidv4 } from "uuid";
import { db } from "./src/db/index.js";
import { users, videos, banners, reactions, settings, comments, comment_reactions } from "./src/db/schema.js";
import { eq, desc, and } from "drizzle-orm";
import { createServer as createViteServer } from "vite";

const JWT_SECRET = process.env.JWT_SECRET || "development_secret";

const uploadDir = process.env.NODE_ENV === "production" 
  ? path.join("/tmp", "uploads") 
  : path.join(process.cwd(), "uploads");

try {
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
} catch (e) {
  console.warn("Could not create uploads directory:", e);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `${uuidv4()}${path.extname(file.originalname)}`);
  },
});
const upload = multer({ 
  storage,
  limits: { fileSize: 3 * 1024 * 1024 * 1024 } // 3GB limit
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '3gb' }));
  app.use(express.urlencoded({ limit: '3gb', extended: true }));
  app.use("/uploads", express.static(uploadDir));

  // Authentication Middleware
  const optionalAuthenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (token == null) return next();

    jwt.verify(token, JWT_SECRET, async (err: any, decodedToken: any) => {
      if (err) return next();
      try {
        if (decodedToken.id === "admin-manoj") {
          req.user = { id: "admin-manoj", email: "Manojkatariya123", displayName: "Admin Manoj", role: "admin" };
          return next();
        }
        
        const userResult = await db.select().from(users).where(eq(users.id, decodedToken.id));
        if (userResult.length > 0) {
          req.user = userResult[0];
        }
        next();
      } catch (e) {
        next();
      }
    });
  };
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, async (err: any, decodedToken: any) => {
      if (err) return res.sendStatus(403);
      try {
        if (decodedToken.id === "admin-manoj") {
          req.user = { id: "admin-manoj", email: "Manojkatariya123", displayName: "Admin Manoj", role: "admin" };
          return next();
        }
        
        const userResult = await db.select().from(users).where(eq(users.id, decodedToken.id));
        if (userResult.length > 0) {
          req.user = userResult[0];
          next();
        } else {
          res.sendStatus(403);
        }
      } catch (e) {
        res.sendStatus(500);
      }
    });
  };

  // API Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, displayName } = req.body;
      const hashedPassword = await bcrypt.hash(password, 10);
      const id = uuidv4();

      await db.insert(users).values({
        id,
        email,
        displayName,
        password_hash: hashedPassword,
      });

      const token = jwt.sign({ id, email, role: "user" }, JWT_SECRET, { expiresIn: "7d" });
      res.json({ token, user: { id, email, displayName, role: "user" } });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (email === "Manojkatariya123" && password === "Ramsahay@123") {
        const adminId = "admin-manoj";
        
        // Ensure the admin user exists in the database to prevent foreign key constraint failures
        const userExists = await db.select().from(users).where(eq(users.id, adminId));
        if (userExists.length === 0) {
          await db.insert(users).values({
            id: adminId,
            email: email,
            displayName: "Admin Manoj",
            role: "admin",
          });
        }
        
        const token = jwt.sign({ id: adminId, email, role: "admin" }, JWT_SECRET, { expiresIn: "7d" });
        return res.json({ token, user: { id: adminId, email, displayName: "Admin Manoj", role: "admin" } });
      }

      const userResult = await db.select().from(users).where(eq(users.email, email));
      if (userResult.length === 0) return res.status(401).json({ error: "Invalid credentials" });
      const user = userResult[0];

      const validPassword = await bcrypt.compare(password, user.password_hash!);
      if (!validPassword) return res.status(401).json({ error: "Invalid credentials" });

      const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: "7d" });
      res.json({ token, user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role } });
    } catch (error: any) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: any, res: any) => {
    try {
      if (req.user.id === "admin-manoj") {
        return res.json({ user: { id: "admin-manoj", email: "Manojkatariya123", displayName: "Admin Manoj", role: "admin" } });
      }
      
      const userResult = await db.select().from(users).where(eq(users.id, req.user.id));
      if (userResult.length === 0) return res.sendStatus(404);
      const user = userResult[0];
      res.json({ user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role } });
    } catch (error) {
      res.sendStatus(500);
    }
  });

  // Videos
  app.get("/api/banners", async (req, res) => {
    try {
      const allBanners = await db.select().from(banners).orderBy(desc(banners.createdAt));
      res.json({ banners: allBanners });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch banners" });
    }
  });

  app.get("/api/videos", async (req, res) => {
    try {
      const allVideos = await db.select().from(videos).orderBy(desc(videos.createdAt));
      res.json({ videos: allVideos });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });

  app.get("/api/videos/:id", optionalAuthenticateToken, async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      const videoResult = await db.select().from(videos).where(eq(videos.id, videoId));
      if (videoResult.length === 0) return res.status(404).json({ error: "Video not found" });
      
      let userReaction = null;
      if (req.user) {
          const reactionResult = await db.select().from(reactions).where(and(eq(reactions.videoId, videoId), eq(reactions.userId, req.user.id)));
          if (reactionResult.length > 0) userReaction = reactionResult[0].type;
      }
      
      res.json({ video: { ...videoResult[0], userReaction } });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch video" });
    }
  });


  app.post("/api/videos/:id/view", async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      const videoResult = await db.select().from(videos).where(eq(videos.id, videoId));
      if (videoResult.length === 0) return res.status(404).json({ error: "Video not found" });

      await db.update(videos).set({ views: (videoResult[0].views || 0) + 1 }).where(eq(videos.id, videoId));
      res.json({ success: true, views: (videoResult[0].views || 0) + 1 });
    } catch (error) {
      res.status(500).json({ error: "Failed to update views" });
    }
  });


  
  app.get("/api/admin/comments", authenticateToken, async (req: any, res: any) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const commentsResult = await db.select({
        id: comments.id,
        videoId: comments.videoId,
        userId: comments.userId,
        text: comments.text,
        likes: comments.likes,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          displayName: users.displayName,
          email: users.email
        },
        video: {
          id: videos.id,
          title: videos.title
        }
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .leftJoin(videos, eq(comments.videoId, videos.id))
      .orderBy(desc(comments.createdAt));

      res.json({ comments: commentsResult });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  app.delete("/api/admin/comments/:id", authenticateToken, async (req: any, res: any) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const commentId = parseInt(req.params.id);
      await db.delete(comments).where(eq(comments.id, commentId));
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to delete comment" });
    }
  });

  app.get("/api/videos/:id/comments", async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      // Join comments with users to get displayName and email
      const commentsResult = await db.select({
        id: comments.id,
        videoId: comments.videoId,
        userId: comments.userId,
        text: comments.text,
        likes: comments.likes,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          displayName: users.displayName,
          email: users.email
        }
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.videoId, videoId))
      .orderBy(desc(comments.createdAt));

      res.json({ comments: commentsResult });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  app.post("/api/videos/:id/comments", authenticateToken, express.json(), async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      const userId = req.user.id;
      const { text } = req.body;

      if (!text || text.trim() === '') {
        return res.status(400).json({ error: "Comment text is required" });
      }

      await db.insert(comments).values({
        videoId,
        userId,
        text: text.trim()
      });

      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to add comment" });
    }
  });

  
  app.post("/api/videos/:id/comments/:commentId/react", authenticateToken, express.json(), async (req: any, res: any) => {
    try {
      const commentId = parseInt(req.params.commentId);
      const { type } = req.body; // 'like', 'dislike', or null
      
      const userId = req.user.id;

      const commentResult = await db.select().from(comments).where(eq(comments.id, commentId));
      if (commentResult.length === 0) {
        return res.status(404).json({ error: "Comment not found" });
      }

      // Find existing reaction
      const existingReaction = await db.select()
        .from(comment_reactions)
        .where(and(
          eq(comment_reactions.commentId, commentId),
          eq(comment_reactions.userId, userId)
        ));

      if (existingReaction.length > 0) {
        if (type === null) {
          // Remove reaction
          await db.delete(comment_reactions).where(eq(comment_reactions.id, existingReaction[0].id));
          if (existingReaction[0].type === 'like') {
            await db.update(comments).set({ likes: commentResult[0].likes - 1 }).where(eq(comments.id, commentId));
          }
        } else if (existingReaction[0].type !== type) {
          // Change reaction
          await db.update(comment_reactions).set({ type }).where(eq(comment_reactions.id, existingReaction[0].id));
          if (type === 'like') {
            await db.update(comments).set({ likes: commentResult[0].likes + 1 }).where(eq(comments.id, commentId));
          } else if (existingReaction[0].type === 'like') {
            await db.update(comments).set({ likes: commentResult[0].likes - 1 }).where(eq(comments.id, commentId));
          }
        }
      } else if (type !== null) {
        // Add new reaction
        await db.insert(comment_reactions).values({
          commentId,
          userId,
          type
        });
        if (type === 'like') {
          await db.update(comments).set({ likes: commentResult[0].likes + 1 }).where(eq(comments.id, commentId));
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to react to comment" });
    }
  });

  app.get("/api/videos/:id/comments/reactions", authenticateToken, async (req: any, res: any) => {
    try {
      const userId = req.user.id;
      const videoId = parseInt(req.params.id);
      
      // Get all comment reactions for this user on this video's comments
      // To do this simply, we fetch all comment reactions for this user, then filter in memory or join
      const userReactions = await db.select({
        commentId: comment_reactions.commentId,
        type: comment_reactions.type
      })
      .from(comment_reactions)
      .where(eq(comment_reactions.userId, userId));
      
      const reactionMap: Record<number, string> = {};
      userReactions.forEach(r => {
        reactionMap[r.commentId] = r.type;
      });

      res.json({ reactions: reactionMap });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch comment reactions" });
    }
  });


  app.post("/api/videos/:id/react", authenticateToken, express.json(), async (req: any, res: any) => {
    try {
      const videoId = parseInt(req.params.id);
      const { type } = req.body; // 'like', 'dislike', or null
      
      const userId = req.user.id;

      const videoResult = await db.select().from(videos).where(eq(videos.id, videoId));
      if (videoResult.length === 0) return res.status(404).json({ error: "Video not found" });

      const existingReaction = await db.select().from(reactions).where(and(eq(reactions.videoId, videoId), eq(reactions.userId, userId)));
      
      let likeChange = 0;
      
      if (existingReaction.length > 0) {
          const oldType = existingReaction[0].type;
          if (oldType === 'like') likeChange -= 1;
          
          if (!type) {
              await db.delete(reactions).where(eq(reactions.id, existingReaction[0].id));
          } else {
              await db.update(reactions).set({ type }).where(eq(reactions.id, existingReaction[0].id));
              if (type === 'like') likeChange += 1;
          }
      } else if (type) {
          await db.insert(reactions).values({ videoId, userId, type });
          if (type === 'like') likeChange += 1;
      }
      
      const newLikes = Math.max(0, (videoResult[0].likes || 0) + likeChange);
      await db.update(videos).set({ likes: newLikes }).where(eq(videos.id, videoId));
      
      res.json({ likes: newLikes, userReaction: type });
    } catch (error) {
      res.status(500).json({ error: "Failed to update reaction" });
    }
  });

  const chunkUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 32 * 1024 * 1024 } });
  
  app.post("/api/upload-chunk", authenticateToken, chunkUpload.single("chunk"), async (req: any, res: any) => {
    try {
      const { uploadId, chunkIndex, totalChunks, originalName } = req.body;
      const chunk = req.file;

      if (!chunk) return res.status(400).json({ error: "No chunk provided" });

      const tempFilePath = path.join(uploadDir, `${uploadId}.temp`);
      
      fs.appendFileSync(tempFilePath, chunk.buffer);

      if (parseInt(chunkIndex) === parseInt(totalChunks) - 1) {
        const ext = path.extname(originalName).toLowerCase();
        const baseUuid = uuidv4();
        const finalFilename = `${baseUuid}${ext}`;
        const finalPath = path.join(uploadDir, finalFilename);
        
        fs.renameSync(tempFilePath, finalPath);

        if (ext === '.mp4' || ext === '.mov') {
          const hlsDir = path.join(uploadDir, baseUuid);
          fs.mkdirSync(hlsDir, { recursive: true });
          const m3u8Path = path.join(hlsDir, 'index.m3u8');
          const hlsUrl = `/uploads/${baseUuid}/index.m3u8`;

          const { exec } = await import('child_process');
          // Run ffmpeg in background
          import("ffmpeg-static").then(ffmpegModule => {
            const ffmpegPath = ffmpegModule.default || ffmpegModule;
            exec(`"${ffmpegPath}" -i "${finalPath}" -map 0:v -map 0:a? -codec copy -hls_time 10 -hls_playlist_type vod -hls_segment_filename "${hlsDir}/seg_%03d.ts" -start_number 0 "${m3u8Path}"`, (error) => {
              if (error) {
                console.error("FFmpeg error:", error);
              } else {
                fs.unlink(finalPath, () => {}); // delete original mp4 to save space
              }
            });
          }).catch(console.error);

          return res.json({ url: hlsUrl, completed: true });
        } else {
          return res.json({ url: `/uploads/${finalFilename}`, completed: true });
        }
      }

      res.json({ success: true, chunkIndex });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to upload chunk" });
    }
  });

  app.post("/api/videos/upload-chunk", authenticateToken, chunkUpload.single("chunk"), async (req: any, res: any) => {
    try {
      const { uploadId, chunkIndex, totalChunks, title, description, category, originalName } = req.body;
      const chunk = req.file;

      if (!chunk) return res.status(400).json({ error: "No chunk provided" });

      const tempFilePath = path.join(uploadDir, `${uploadId}.temp`);
      
      fs.appendFileSync(tempFilePath, chunk.buffer);

      if (parseInt(chunkIndex) === parseInt(totalChunks) - 1) {
        const ext = path.extname(originalName).toLowerCase();
        const baseUuid = uuidv4();
        const finalFilename = `${baseUuid}${ext}`;
        const finalPath = path.join(uploadDir, finalFilename);
        
        fs.renameSync(tempFilePath, finalPath);

        let finalUrl = `/uploads/${finalFilename}`;

        if (ext === '.mp4' || ext === '.mov') {
          const hlsDir = path.join(uploadDir, baseUuid);
          fs.mkdirSync(hlsDir, { recursive: true });
          const m3u8Path = path.join(hlsDir, 'index.m3u8');
          finalUrl = `/uploads/${baseUuid}/index.m3u8`;

          const { exec } = await import('child_process');
          // Run ffmpeg in background
          import("ffmpeg-static").then(ffmpegModule => {
            const ffmpegPath = ffmpegModule.default || ffmpegModule;
            exec(`"${ffmpegPath}" -i "${finalPath}" -map 0:v -map 0:a? -codec copy -hls_time 10 -hls_playlist_type vod -hls_segment_filename "${hlsDir}/seg_%03d.ts" -start_number 0 "${m3u8Path}"`, (error) => {
              if (error) {
                console.error("FFmpeg error:", error);
              } else {
                fs.unlink(finalPath, () => {});
              }
            });
          }).catch(console.error);
        }

        const newVideo = await db.insert(videos).values({
          userId: req.user.id,
          title: title || "Untitled",
          description: description || "",
          category: category || "Uncategorized",
          videoUrl: finalUrl,
          status: req.user.role === 'admin' ? 'approved' : 'pending'
        }).returning();
        
        return res.json({ video: newVideo[0], completed: true });
      }

      res.json({ success: true, chunkIndex });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to upload chunk" });
    }
  });

  app.post("/api/videos/upload", authenticateToken, upload.single("video"), async (req: any, res: any) => {
    try {
      const { title, description, category } = req.body;
      const file = req.file;

      if (!file) return res.status(400).json({ error: "No video file provided" });

      const newVideo = await db.insert(videos).values({
        userId: req.user.id,
        title,
        description,
        category,
        videoUrl: `/uploads/${file.filename}`,
        status: "approved", // auto-approve so it shows until deleted
      }).returning();

      res.json({ video: newVideo[0] });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Upload failed" });
    }
  });

  // Admin Routes
  app.post("/api/admin/banners", authenticateToken, express.json(), async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const { title } = req.body;
      const { imageUrls } = req.body;
      if (!imageUrls || imageUrls.length === 0) return res.status(400).json({ error: "No image urls provided" });
      
      const inserted = [];
      for (const url of imageUrls) {
        const newBanner = await db.insert(banners).values({
          title: title || "New Banner",
          imageUrl: url,
          active: true
        }).returning();
        inserted.push(newBanner[0]);
      }
      
      res.json({ banners: inserted });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to upload banner" });
    }
  });

  app.put("/api/admin/banners/:id/active", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const b = await db.select().from(banners).where(eq(banners.id, parseInt(req.params.id)));
      if (b.length) {
        await db.update(banners).set({ active: !b[0].active }).where(eq(banners.id, parseInt(req.params.id)));
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update banner status" });
    }
  });
  
  app.delete("/api/admin/banners/:id", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      await db.delete(banners).where(eq(banners.id, parseInt(req.params.id)));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete banner" });
    }
  });

  app.get("/api/admin/users", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const allUsers = await db.select().from(users).orderBy(desc(users.createdAt));
      res.json({ users: allUsers });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.put("/api/admin/users/:id/status", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const { status } = req.body;
      await db.update(users).set({ status }).where(eq(users.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update user status" });
    }
  });

  app.get("/api/admin/videos", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const allVideos = await db.select().from(videos).orderBy(desc(videos.createdAt));
      res.json({ videos: allVideos });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });

  app.post("/api/admin/videos/:id/approve", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      await db.update(videos).set({ status: "approved" }).where(eq(videos.id, parseInt(req.params.id)));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to approve video" });
    }
  });

  app.post("/api/admin/videos/:id/reject", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const { reason } = req.body;
      await db.update(videos).set({ status: "rejected", rejectionReason: reason }).where(eq(videos.id, parseInt(req.params.id)));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to reject video" });
    }
  });

  app.post("/api/admin/videos/add", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const { title, description, genre, poster, video, status } = req.body;
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      let finalVideoUrl = video;
      let finalThumbnailUrl = poster;

      if (files?.videoFile?.[0] && files.videoFile[0].size > 0) {
        finalVideoUrl = `/uploads/${files.videoFile[0].filename}`;
      }
      if (files?.posterFile?.[0] && files.posterFile[0].size > 0) {
        finalThumbnailUrl = `/uploads/${files.posterFile[0].filename}`;
      }

      let dbStatus = "approved";
      if (status === "draft") dbStatus = "pending";
      if (status === "off") dbStatus = "rejected";
      if (status === "live") dbStatus = "approved";

      const newVideo = await db.insert(videos).values({
        userId: req.user.id,
        title: title || "Untitled",
        description: description || "",
        category: genre || "Drama",
        videoUrl: finalVideoUrl || "",
        thumbnailUrl: finalThumbnailUrl || null,
        status: dbStatus,
      }).returning();

      res.json({ success: true, video: newVideo[0] });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to add video" });
    }
  });

  app.put("/api/admin/videos/:id", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      // If it's just a status update from toggleStatus (JSON)
      if (req.headers['content-type'] === 'application/json') {
        const { status } = req.body;
        if (status) {
          await db.update(videos).set({ status }).where(eq(videos.id, parseInt(req.params.id)));
        }
        return res.json({ success: true });
      }

      // Otherwise it's a full edit from FormData
      const { title, description, genre, poster, video, status } = req.body;
      const files = req.files as { [fieldname: string]: Express.Multer.File[] } | undefined;
      
      let finalVideoUrl = video;
      let finalThumbnailUrl = poster;

      if (files?.videoFile?.[0] && files.videoFile[0].size > 0) {
        finalVideoUrl = `/uploads/${files.videoFile[0].filename}`;
      }
      if (files?.posterFile?.[0] && files.posterFile[0].size > 0) {
        finalThumbnailUrl = `/uploads/${files.posterFile[0].filename}`;
      }

      const updateData: any = {};
      if (title) updateData.title = title;
      if (description !== undefined) updateData.description = description;
      if (genre) updateData.category = genre;
      if (finalVideoUrl !== undefined) updateData.videoUrl = finalVideoUrl;
      if (finalThumbnailUrl !== undefined) updateData.thumbnailUrl = finalThumbnailUrl;
      if (status) updateData.status = status;

      if (Object.keys(updateData).length > 0) {
        await db.update(videos).set(updateData).where(eq(videos.id, parseInt(req.params.id)));
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update video" });
    }
  });

  app.delete("/api/admin/videos/:id", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      await db.delete(videos).where(eq(videos.id, parseInt(req.params.id)));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete video" });
    }
  });


  // Settings Routes
  app.get("/api/settings", async (req, res) => {
    try {
      const allSettings = await db.select().from(settings);
      const settingsMap = allSettings.reduce((acc: any, curr) => {
        acc[curr.key] = curr.value;
        return acc;
      }, {});
      res.json(settingsMap);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.put("/api/admin/settings", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const { key, value } = req.body;
      
      const existing = await db.select().from(settings).where(eq(settings.key, key));
      if (existing.length > 0) {
        await db.update(settings).set({ value }).where(eq(settings.key, key));
      } else {
        await db.insert(settings).values({ key, value });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to update setting" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
