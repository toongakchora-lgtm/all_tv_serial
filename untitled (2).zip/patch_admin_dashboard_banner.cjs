const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

code = code.replace(
  'const [newBannerImage, setNewBannerImage] = useState<File | null>(null);',
  'const [newBannerImages, setNewBannerImages] = useState<File[]>([]);'
);

code = code.replace(
  `  const addBanner = async () => {
    const val = newBannerTitle.trim() || "New Banner";
    if (!newBannerImage) {
      alert("Please select an image");
      return;
    }

    const checkAspectRatio = (file: any) => {
      return new Promise((resolve) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => {
          const ratio = img.width / img.height;
          // allow ~16:9 like 1.77
          if (ratio >= 1.7 && ratio <= 1.8) {
            resolve(true);
          } else {
            resolve(false);
          }
          URL.revokeObjectURL(url);
        };
        img.onerror = () => resolve(false);
        img.src = url;
      });
    };

    const isValid = await checkAspectRatio(newBannerImage);
    if (!isValid) {
      alert("Only 16:9 aspect ratio images are allowed (e.g., 1920x1080 or 1280x720).");
      return;
    }

    const formData = new FormData();
    formData.append("title", val);
    formData.append("image", newBannerImage);`,
  `  const addBanner = async () => {
    const val = newBannerTitle.trim() || "New Banner";
    if (newBannerImages.length === 0) {
      alert("Please select at least one image");
      return;
    }

    const formData = new FormData();
    formData.append("title", val);
    for (let i = 0; i < newBannerImages.length; i++) {
      formData.append("images", newBannerImages[i]);
    }`
);

// We need to fix the input file field and the preview
code = code.replace(
  '<input type="file" accept="image/*" onChange={e => setNewBannerImage(e.target.files?.[0] || null)}',
  '<input type="file" multiple accept="image/*" onChange={e => setNewBannerImages(Array.from(e.target.files || []))}'
);

code = code.replace(
  `{newBannerImage && (
                    <div style={{marginTop: '12px'}}>
                      <img src={URL.createObjectURL(newBannerImage)} style={{width: '100%', aspectRatio: '16/9', objectFit: 'cover', borderRadius: '12px', border: '1px solid var(--line)'}} alt="Preview" />
                    </div>
                  )}`,
  `{newBannerImages.length > 0 && (
                    <div style={{marginTop: '12px', display: 'flex', gap: '10px', overflowX: 'auto'}}>
                      {newBannerImages.map((img, i) => (
                        <img key={i} src={URL.createObjectURL(img)} style={{height: '80px', aspectRatio: '16/9', objectFit: 'cover', borderRadius: '8px', border: '1px solid var(--line)'}} alt="Preview" />
                      ))}
                    </div>
                  )}`
);

code = code.replace(
  'setNewBannerImage(null);',
  'setNewBannerImages([]);'
);

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
