const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'app.post("/api/admin/banners", authenticateToken, upload.single("image"), async (req: any, res: any) => {',
  'app.post("/api/admin/banners", authenticateToken, upload.array("images", 10), async (req: any, res: any) => {'
);

code = code.replace(
  `      const file = req.file;
      
      if (!file) return res.status(400).json({ error: "No image file provided" });
      
      // Deactivate other banners
      await db.update(banners).set({ active: false });
      
      const newBanner = await db.insert(banners).values({
        title: title || "New Banner",
        imageUrl: \`/uploads/\${file.filename}\`,
        active: true
      }).returning();
      
      res.json({ banner: newBanner[0] });`,
  `      const files = req.files;
      
      if (!files || files.length === 0) return res.status(400).json({ error: "No image files provided" });
      
      const inserted = [];
      for (const file of files) {
        const newBanner = await db.insert(banners).values({
          title: title || "New Banner",
          imageUrl: \`/uploads/\${file.filename}\`,
          active: true
        }).returning();
        inserted.push(newBanner[0]);
      }
      
      res.json({ banners: inserted });`
);

code = code.replace(
  `  app.put("/api/admin/banners/:id/active", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      await db.update(banners).set({ active: false });
      await db.update(banners).set({ active: true }).where(eq(banners.id, parseInt(req.params.id)));
      res.json({ success: true });`,
  `  app.put("/api/admin/banners/:id/active", authenticateToken, async (req: any, res: any) => {
    if (req.user.role !== "admin") return res.sendStatus(403);
    try {
      const b = await db.select().from(banners).where(eq(banners.id, parseInt(req.params.id)));
      if (b.length) {
        await db.update(banners).set({ active: !b[0].active }).where(eq(banners.id, parseInt(req.params.id)));
      }
      res.json({ success: true });`
);

fs.writeFileSync('server.ts', code);
