const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// Add siteName to Navigation props
code = code.replace('function Navigation({ user }: any) {', 'function Navigation({ user, siteName }: any) {');
code = code.replace('<span>SK Stream</span>', '<span>{siteName || "SK Stream"}</span>');

// Add siteName to MainAppLayout props
code = code.replace('function MainAppLayout({ user, setUser }: any) {', 'function MainAppLayout({ user, setUser, siteName }: any) {');
code = code.replace('<Navigation user={user} />', '<Navigation user={user} siteName={siteName} />');

// Update App to fetch siteName
const appCodeStart = `export default function App() {
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [siteName, setSiteName] = useState("SK Stream");

  useEffect(() => {
    fetch("/api/settings")
      .then(res => res.json())
      .then(data => {
        if (data.website_name) setSiteName(data.website_name);
      })
      .catch(console.error);

    const token = localStorage.getItem("token");`;

code = code.replace(`export default function App() {
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");`, appCodeStart);

code = code.replace('<Route path="*" element={<MainAppLayout user={user} setUser={setUser} />} />', '<Route path="*" element={<MainAppLayout user={user} setUser={setUser} siteName={siteName} />} />');

fs.writeFileSync('src/App.tsx', code);
