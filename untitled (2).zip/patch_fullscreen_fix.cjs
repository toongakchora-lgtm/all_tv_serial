const fs = require('fs');
let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

const fullscreenBtn = `
          <button className="control-btn fullscreen" aria-label="Fullscreen" onClick={(e) => {
            e.stopPropagation();
            const el = videoRef.current?.parentElement as any;
            if (el) {
              const isFullscreen = document.fullscreenElement || (document as any).webkitFullscreenElement;
              if (isFullscreen) {
                if (document.exitFullscreen) {
                  document.exitFullscreen();
                } else if ((document as any).webkitExitFullscreen) {
                  (document as any).webkitExitFullscreen();
                }
                if (window.screen && window.screen.orientation && window.screen.orientation.unlock) {
                  window.screen.orientation.unlock();
                }
              } else {
                const reqFs = el.requestFullscreen || el.webkitRequestFullscreen || el.mozRequestFullScreen || el.msRequestFullscreen;
                if (reqFs) {
                  const p = reqFs.call(el);
                  if (p && p.then) {
                    p.then(() => {
                      if (window.screen && window.screen.orientation && window.screen.orientation.lock) {
                        window.screen.orientation.lock('landscape').catch(err => console.log(err));
                      }
                    }).catch((e: any) => console.error(e));
                  } else {
                    // For browsers that don't return a promise (like Safari)
                    if (window.screen && window.screen.orientation && window.screen.orientation.lock) {
                      window.screen.orientation.lock('landscape').catch(err => console.log(err));
                    }
                  }
                }
              }
            }
          }} style={{ position: 'absolute', bottom: '16px', right: '16px', width: '40px', height: '40px', zIndex: 10 }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{width: '20px', height: '20px'}}>
              <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path>
            </svg>
          </button>
        </div>
`;

code = code.replace(
  /          <button className="control-btn fullscreen"[\s\S]*?<\/button>\s*<\/div>/,
  fullscreenBtn.trim() + '\n'
);

fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
