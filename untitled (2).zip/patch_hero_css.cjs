const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');

if (!css.includes('z-index: 1; pointer-events: none;')) {
  css = css.replace(
    '.hero::after {\n  content: ""; position: absolute; inset: 0;',
    '.hero::after {\n  content: ""; position: absolute; inset: 0; z-index: 1; pointer-events: none;'
  );
  fs.writeFileSync('src/index.css', css);
}
