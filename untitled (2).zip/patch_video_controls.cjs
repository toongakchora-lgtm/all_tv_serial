const fs = require('fs');
let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

if (!code.includes('const [isPaused, setIsPaused] = useState(false);')) {
  code = code.replace(
    'const [restricted, setRestricted] = useState(false);',
    'const [restricted, setRestricted] = useState(false);\n  const [isPaused, setIsPaused] = useState(false);\n  const [showControls, setShowControls] = useState(true);'
  );
  
  const customControls = `
      <div style={{background: '#000', borderRadius: '15px', overflow: 'hidden', aspectRatio: '16/9', position: 'relative'}}
           onMouseEnter={() => setShowControls(true)}
           onMouseLeave={() => setShowControls(false)}
           onClick={() => {
             if (videoRef.current) {
               if (isPaused) {
                 videoRef.current.play();
                 setIsPaused(false);
               } else {
                 videoRef.current.pause();
                 setIsPaused(true);
               }
             }
           }}
      >
        <video 
          ref={videoRef}
          autoPlay 
          onTimeUpdate={handleTimeUpdate}
          onPlay={() => setIsPaused(false)}
          onPause={() => setIsPaused(true)}
          style={{width: '100%', height: '100%', objectFit: 'contain'}}
        />
        
        <div className="custom-video-controls" style={{
          position: 'absolute',
          inset: 0,
          opacity: showControls || isPaused ? 1 : 0,
          transition: 'opacity 0.3s',
          pointerEvents: showControls || isPaused ? 'auto' : 'none',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 'clamp(28px, 8vw, 105px)',
          background: isPaused ? 'rgba(0,0,0,0.3)' : 'transparent',
        }}>
          <button className="control-btn previous" aria-label="Previous video" onClick={(e) => { e.stopPropagation(); /* TODO: previous logic */ }}>
            <svg viewBox="0 0 64 64" aria-hidden="true">
              <rect x="7" y="14" width="6" height="36" rx="3" fill="#8A8A8D"/>
              <path d="M49.5 14.7v34.6c0 1.7-1.9 2.7-3.3 1.8L18.9 33.8a2.15 2.15 0 0 1 0-3.6l27.3-17.3c1.4-.9 3.3.1 3.3 1.8Z" fill="#8A8A8D"/>
            </svg>
          </button>

          <button className="control-btn play-pause" aria-label={isPaused ? "Play video" : "Pause video"} onClick={(e) => {
            e.stopPropagation();
            if (videoRef.current) {
              if (isPaused) {
                videoRef.current.play();
                setIsPaused(false);
              } else {
                videoRef.current.pause();
                setIsPaused(true);
              }
            }
          }}>
            {isPaused ? (
              <svg viewBox="0 0 64 64" aria-hidden="true">
                <path d="M21 11.5 51 30.2a2.1 2.1 0 0 1 0 3.6L21 52.5c-1.5.9-3.4-.1-3.4-1.8V13.3c0-1.7 1.9-2.7 3.4-1.8Z" fill="#FFFFFF"/>
              </svg>
            ) : (
              <svg viewBox="0 0 64 64" aria-hidden="true">
                <rect x="13" y="7" width="14" height="50" rx="5" fill="#FFFFFF"/>
                <rect x="37" y="7" width="14" height="50" rx="5" fill="#FFFFFF"/>
              </svg>
            )}
          </button>

          <button className="control-btn next" aria-label="Next video" onClick={(e) => { e.stopPropagation(); /* TODO: next logic */ }}>
            <svg viewBox="0 0 64 64" aria-hidden="true">
              <path d="M14.5 14.7v34.6c0 1.7 1.9 2.7 3.3 1.8l27.3-17.3a2.15 2.15 0 0 0 0-3.6L17.8 12.9c-1.4-.9-3.3.1-3.3 1.8Z" fill="#FFFFFF"/>
              <rect x="51" y="14" width="6" height="36" rx="3" fill="#FFFFFF"/>
            </svg>
          </button>
        </div>
      </div>
  `;

  code = code.replace(
    /<div style=\{\{background: '#000', borderRadius: '15px', overflow: 'hidden', aspectRatio: '16\/9'\}\}>\s*<video[\s\S]*?\/>\s*<\/div>/,
    customControls
  );

  fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
}
