const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  '          <Link to="/library" className={path === \'/library\' ? \'active\' : \'\'}>Library</Link>\n          <Link to="/saved" className={path === \'/saved\' ? \'active\' : \'\'}>Library</Link>',
  '          <Link to="/library" className={path === \'/library\' ? \'active\' : \'\'}>Library</Link>'
);

code = code.replace(
  '        <Link to="/saved" className={path === \'/saved\' ? \'active\' : \'\'}>\n          <span className="ico"><Bookmark width={22} /></span><span>Library</span>\n        </Link>',
  '        <Link to="/library" className={path === \'/library\' ? \'active\' : \'\'}>\n          <span className="ico"><Bookmark width={22} /></span><span>Library</span>\n        </Link>'
);

fs.writeFileSync('src/App.tsx', code);
