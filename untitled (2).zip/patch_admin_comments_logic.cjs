const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

if (!code.includes('const [comments, setComments] = useState<any[]>([]);')) {
  code = code.replace(
    'const [users, setUsers] = useState<any[]>([]);',
    'const [users, setUsers] = useState<any[]>([]);\n  const [comments, setComments] = useState<any[]>([]);'
  );
}

if (!code.includes('const fetchComments = () => {')) {
  code = code.replace(
    'const fetchUsers = () => {',
    `const fetchComments = () => {
    const token = localStorage.getItem("token");
    fetch("/api/admin/comments", {
      headers: { Authorization: \`Bearer \${token}\` }
    })
      .then(res => res.json())
      .then(data => {
        if (data.comments) setComments(data.comments);
      })
      .catch(console.error);
  };

  const fetchUsers = () => {`
  );
}

if (!code.includes('fetchComments();')) {
  code = code.replace(
    'fetchUsers();',
    'fetchUsers();\n    fetchComments();'
  );
}

const deleteCommentFunc = `
  const deleteComment = async (id: number) => {
    if (!window.confirm("Are you sure you want to delete this comment?")) return;
    const token = localStorage.getItem("token");
    try {
      const res = await fetch(\`/api/admin/comments/\${id}\`, {
        method: "DELETE",
        headers: { Authorization: \`Bearer \${token}\` }
      });
      if (res.ok) {
        fetchComments();
      }
    } catch (error) {
      console.error(error);
      alert("Failed to delete comment");
    }
  };
`;

if (!code.includes('const deleteComment = async')) {
  code = code.replace(
    'const toggleUserRole = async (userId: number, currentRole: string) => {',
    deleteCommentFunc + '\n\n  const toggleUserRole = async (userId: number, currentRole: string) => {'
  );
}

const commentsSection = `
          <section className={\`admin-page \${activeSection === 'comments' ? 'active' : ''}\`}>
            <div className="admin-card">
              <div className="admin-card-head">
                <h3>All Comments</h3>
              </div>
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>User</th>
                      <th>Comment</th>
                      <th>Video</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {comments.map(c => (
                      <tr key={c.id}>
                        <td>
                          <div style={{ fontWeight: 600 }}>{c.user?.displayName || 'Unknown'}</div>
                          <div style={{ fontSize: '11px', color: 'var(--muted)' }}>{c.user?.email || ''}</div>
                        </td>
                        <td>{c.text}</td>
                        <td>{c.video?.title || 'Unknown Video'}</td>
                        <td>{new Date(c.createdAt).toLocaleDateString()}</td>
                        <td>
                          <button className="admin-btn" style={{ background: '#ef4444' }} onClick={() => deleteComment(c.id)}>Delete</button>
                        </td>
                      </tr>
                    ))}
                    {comments.length === 0 && (
                      <tr><td colSpan={5} style={{textAlign: 'center', padding: '20px', color: 'var(--muted)'}}>No comments found</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
`;

if (!code.includes('activeSection === \'comments\'')) {
  code = code.replace(
    '          <section className={`admin-page ${activeSection === \'settings\' ? \'active\' : \'\'}`}>',
    commentsSection + '\n          <section className={`admin-page ${activeSection === \'settings\' ? \'active\' : \'\'}`}>'
  );
}

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
