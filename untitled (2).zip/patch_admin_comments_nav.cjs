const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

if (!code.includes('{ id: \'comments\', label: \'Comments\',')) {
  code = code.replace(
    "{ id: 'ads', label: 'Ads & Revenue', icon: <IndianRupee width={18} /> },",
    "{ id: 'ads', label: 'Ads & Revenue', icon: <IndianRupee width={18} /> },\n    { id: 'comments', label: 'Comments', icon: <svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" strokeWidth=\"2\" strokeLinecap=\"round\" strokeLinejoin=\"round\"><path d=\"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z\"/></svg> },"
  );
  fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
}
