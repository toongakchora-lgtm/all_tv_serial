const fs = require('fs');
const glob = require('glob');

const files = glob.sync('src/**/*.tsx');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/\.then\(res => res\.json\(\)\)/g, 
    ".then(async res => { const text = await res.text(); try { return JSON.parse(text); } catch(e) { return {}; } })"
  );
  fs.writeFileSync(file, content);
});
