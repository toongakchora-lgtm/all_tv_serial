const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'app.get("/api/admin/comments", authenticateToken, async (req, res) => {',
  'app.get("/api/admin/comments", authenticateToken, async (req: any, res: any) => {'
);

code = code.replace(
  'app.delete("/api/admin/comments/:id", authenticateToken, async (req, res) => {',
  'app.delete("/api/admin/comments/:id", authenticateToken, async (req: any, res: any) => {'
);

fs.writeFileSync('server.ts', code);
