const fs = require('fs');
let code = fs.readFileSync('src/pages/Home.tsx', 'utf8');

code = code.replace(
  'const [activeBanner, setActiveBanner] = useState<any>(null);',
  'const [activeBanners, setActiveBanners] = useState<any[]>([]);\n  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);'
);

code = code.replace(
  `        .then(data => {
          if (data.banners) {
            const active = data.banners.find((b: any) => b.active);
            setActiveBanner(active || null);
          } else {
            setActiveBanner(null);
          }
        })`,
  `        .then(data => {
          if (data.banners) {
            const active = data.banners.filter((b: any) => b.active);
            setActiveBanners(active);
          } else {
            setActiveBanners([]);
          }
        })`
);

const useEffectBanners = `
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentBannerIndex(prev => (prev + 1) % activeBanners.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [activeBanners.length]);
`;

code = code.replace(
  '  const heroVideo = videos.length > 0 ? videos[0] : null;',
  useEffectBanners + '\n  const heroVideo = videos.length > 0 ? videos[0] : null;'
);

const heroRender = `      {activeBanners.length > 0 && (
        <section className="hero" style={{ overflow: 'hidden', position: 'relative' }}>
          <div style={{
            display: 'flex',
            transition: 'transform 0.5s ease-in-out',
            transform: \`translateX(-\${currentBannerIndex * 100}%)\`,
            width: '100%',
            height: '100%'
          }}>
            {activeBanners.map((b, i) => (
              <div key={b.id} style={{ minWidth: '100%', position: 'relative', height: '100%' }}>
                <img src={b.imageUrl} alt={b.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div className="hero-content">
                  <span className="tag">#1 Trending</span>
                  <h1>{b.title}</h1>
                  <p>Watch top trending content and short dramas right now on {siteName || "SK Stream"}.</p>
                  <div className="hero-actions">
                    <Link to="/discover" className="btn primary">
                      <Play width={16} fill="currentColor" /> Watch Now
                    </Link>
                    <button className="btn">
                      <Plus width={16} /> My List
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div style={{ position: 'absolute', bottom: '10px', left: '0', right: '0', display: 'flex', justifyContent: 'center', gap: '6px' }}>
            {activeBanners.map((_, i) => (
              <div key={i} style={{ width: i === currentBannerIndex ? '20px' : '6px', height: '6px', borderRadius: '3px', background: i === currentBannerIndex ? 'var(--brand)' : 'rgba(255,255,255,0.5)', transition: 'all 0.3s ease' }}></div>
            ))}
          </div>
        </section>
      )}`;

code = code.replace(
  /\{activeBanner && \([\s\S]*?<\/section>\s*\)\}/,
  heroRender
);

fs.writeFileSync('src/pages/Home.tsx', code);
