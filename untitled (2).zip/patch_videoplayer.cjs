const fs = require('fs');

let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

// add state
code = code.replace(
  'const [userReaction, setUserReaction] = useState<\'like\' | \'dislike\' | null>(null);',
  'const [userReaction, setUserReaction] = useState<\'like\' | \'dislike\' | null>(null);\n  const [viewCounted, setViewCounted] = useState(false);'
);

// add function
const timeUpdateFn = `
  const handleTimeUpdate = () => {
    if (videoRef.current && !viewCounted && video) {
      if (videoRef.current.currentTime > 30) {
        setViewCounted(true);
        fetch(\`/api/videos/\${id}/view\`, { method: "POST" })
          .then(res => res.json())
          .then(data => {
            if (data.success) {
               setVideo((v: any) => ({ ...v, views: data.views }));
            }
          })
          .catch(console.error);
      }
    }
  };
`;

code = code.replace('  const handleLike = () => {', timeUpdateFn + '\n  const handleLike = () => {');

// add to video tag
code = code.replace(
  '<video \n          ref={videoRef}\n          controls \n          autoPlay \n          style={{width: \'100%\', height: \'100%\', objectFit: \'contain\'}}\n        />',
  '<video \n          ref={videoRef}\n          controls \n          autoPlay \n          onTimeUpdate={handleTimeUpdate}\n          style={{width: \'100%\', height: \'100%\', objectFit: \'contain\'}}\n        />'
);

// replace also if they are inline (just in case formatting is different)
code = code.replace(
  '<video \n          ref={videoRef}\n          controls \n          autoPlay \n          style={{width: \'100%\', height: \'100%\', objectFit: \'contain\'}}\n        />',
  '<video \n          ref={videoRef}\n          controls \n          autoPlay \n          onTimeUpdate={handleTimeUpdate}\n          style={{width: \'100%\', height: \'100%\', objectFit: \'contain\'}}\n        />'
);

fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
