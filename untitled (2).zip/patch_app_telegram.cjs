const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes('TelegramPopup')) {
  code = code.replace(
    'import PlatformVideos from "./pages/PlatformVideos";',
    'import PlatformVideos from "./pages/PlatformVideos";\nimport TelegramPopup from "./components/TelegramPopup";'
  );
  
  code = code.replace(
    'return (\n    <div className="app">\n      <Navigation user={user} siteName={siteName} />',
    'return (\n    <div className="app">\n      <TelegramPopup />\n      <Navigation user={user} siteName={siteName} />'
  );
  fs.writeFileSync('src/App.tsx', code);
}
