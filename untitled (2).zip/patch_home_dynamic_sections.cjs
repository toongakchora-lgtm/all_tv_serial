const fs = require('fs');
let code = fs.readFileSync('src/pages/Home.tsx', 'utf8');

code = code.replace(
  'const [currentBannerIndex, setCurrentBannerIndex] = useState(0);',
  'const [currentBannerIndex, setCurrentBannerIndex] = useState(0);\n  const [homeSections, setHomeSections] = useState<any[]>([]);'
);

const fetchSectionsCode = `
    const fetchSections = () => {
      fetch("/api/settings")
        .then(res => res.json())
        .then(data => {
          if (data.homepage_sections) {
            try {
              setHomeSections(JSON.parse(data.homepage_sections));
            } catch(e) {}
          } else {
            setHomeSections([
              { id: '1', title: 'Continue Watching', type: 'continue_watching', landscape: true },
              { id: '2', title: 'Short Dramas', type: 'category', category: 'Short Dramas', landscape: false },
              { id: '3', title: 'Movies & Web Series', type: 'category', category: 'Movies', landscape: true },
              { id: '4', title: 'Trending Now', type: 'trending', landscape: false }
            ]);
          }
        })
        .catch(console.error);
    };
    fetchSections();
`;

code = code.replace(
  '    fetchBanners();\n    const bannerInterval = setInterval(fetchBanners, 3000);',
  '    fetchBanners();\n    const bannerInterval = setInterval(fetchBanners, 3000);\n' + fetchSectionsCode
);

code = code.replace(
  '  const continueWatching = videos.slice(1, 4);\n  const shortDramas = videos.slice(0, 6);\n  const movies = videos.slice(2, 6);\n  const trending = [...videos].sort((a, b) => (b.views || 0) - (a.views || 0));',
  ''
);

const renderDynamicSections = `
        <>
          {homeSections.map(sec => {
            let items: any[] = [];
            if (sec.type === 'continue_watching') {
              items = videos.slice(1, 4); // Dummy for now
            } else if (sec.type === 'trending') {
              items = [...videos].sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 6);
            } else if (sec.type === 'category') {
              items = videos.filter(v => v.category === sec.category);
            }
            return <React.Fragment key={sec.id}>{renderSection(sec.title, items, sec.landscape)}</React.Fragment>;
          })}
        </>
`;

code = code.replace(
  /<>\s*\{renderSection\('Continue Watching', continueWatching, true\)\}\s*\{renderSection\('Short Dramas', shortDramas\)\}\s*\{renderSection\('Movies & Web Series', movies, true\)\}\s*\{renderSection\('Trending Now', trending\)\}\s*<\/>/,
  renderDynamicSections
);

fs.writeFileSync('src/pages/Home.tsx', code);
