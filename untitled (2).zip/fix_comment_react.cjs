const fs = require('fs');
let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

const handleCommentReactionFunc = `
  const handleCommentReaction = async (commentId: number, type: 'like' | 'dislike') => {
    if (!user) {
      alert("Please login to react to comments.");
      return;
    }
    const currentReaction = commentReactions[commentId];
    const newType = currentReaction === type ? null : type;
    
    // Optimistic UI update
    setCommentReactions(prev => ({ ...prev, [commentId]: newType || '' }));
    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        let newLikes = c.likes;
        if (currentReaction === 'like' && newType !== 'like') newLikes--;
        else if (currentReaction !== 'like' && newType === 'like') newLikes++;
        return { ...c, likes: newLikes };
      }
      return c;
    }));

    try {
      const token = localStorage.getItem('token');
      await fetch(\`/api/videos/\${id}/comments/\${commentId}/react\`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: \`Bearer \${token}\`
        },
        body: JSON.stringify({ type: newType })
      });
    } catch (error) {
      console.error(error);
    }
  };
`;

if (!code.includes('const handleCommentReaction =')) {
  code = code.replace(
    'const handleCommentSubmit = (e: React.FormEvent) => {',
    handleCommentReactionFunc + '\n\n  const handleCommentSubmit = (e: React.FormEvent) => {'
  );
}

fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
