const fs = require('fs');
let code = fs.readFileSync('src/pages/VideoPlayer.tsx', 'utf8');

// Update handleTimeUpdate
code = code.replace(
  'const handleTimeUpdate = () => {',
  `const handleTimeUpdate = () => {
    if (videoRef.current && id) {
      try {
        const hist = JSON.parse(localStorage.getItem('dv_history') || '{}');
        hist[id] = {
          time: videoRef.current.currentTime,
          percent: (videoRef.current.currentTime / videoRef.current.duration) * 100,
          updated: Date.now()
        };
        localStorage.setItem('dv_history', JSON.stringify(hist));
      } catch (e) {}
    }`
);

// Update handleSave
code = code.replace(
  '  const handleSave = () => {\n    if (!user) {',
  `  const [isFav, setIsFav] = useState(false);
  
  useEffect(() => {
    if (id) {
      try {
        const favs = JSON.parse(localStorage.getItem('dv_favs') || '[]');
        setIsFav(favs.includes(Number(id)));
      } catch (e) {}
    }
  }, [id]);

  const handleSave = () => {
    if (id) {
      try {
        let favs = JSON.parse(localStorage.getItem('dv_favs') || '[]');
        if (favs.includes(Number(id))) {
          favs = favs.filter((x: number) => x !== Number(id));
          setIsFav(false);
        } else {
          favs.push(Number(id));
          setIsFav(true);
        }
        localStorage.setItem('dv_favs', JSON.stringify(favs));
        alert(isFav ? "Removed from Library" : "Saved to Library");
        return;
      } catch(e) {}
    }
    if (!user) {`
);

// Update Save button text
code = code.replace(
  '<Bookmark width={18} /> Save',
  '<Bookmark width={18} fill={isFav ? "white" : "none"} /> {isFav ? "Saved" : "Save"}'
);

fs.writeFileSync('src/pages/VideoPlayer.tsx', code);
