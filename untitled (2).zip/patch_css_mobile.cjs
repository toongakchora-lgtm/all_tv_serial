const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');

css += `\n
@media (max-width: 767px) {
  .hero-content h1, .hero p, .tag { display: none !important; }
  .hero-content { bottom: 16px; left: 0; right: 0; padding: 0 16px; }
  .hero-actions { margin-top: 0; justify-content: center; }
  .hero::after {
    background: linear-gradient(0deg, rgba(0, 0, 0, .7), transparent 40%) !important;
  }
}
`;

fs.writeFileSync('src/index.css', css);
