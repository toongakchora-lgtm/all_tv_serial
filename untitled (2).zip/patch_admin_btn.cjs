const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  '<Link to="/admin" className="pill-btn primary">Admin</Link>',
  '<Link to="/admin" className="pill-btn primary desktop-only">Admin</Link>'
);

fs.writeFileSync('src/App.tsx', code);

let css = fs.readFileSync('src/index.css', 'utf8');
if (!css.includes('.desktop-only { display: none !important; }')) {
  css += `\n@media (max-width: 767px) {\n  .desktop-only { display: none !important; }\n}\n`;
  fs.writeFileSync('src/index.css', css);
}

