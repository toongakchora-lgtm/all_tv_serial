const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'app.post("/api/admin/videos/add", authenticateToken, upload.fields([{ name: \'videoFile\', maxCount: 1 }, { name: \'posterFile\', maxCount: 1 }]), async (req: any, res: any) => {',
  'app.post("/api/admin/videos/add", authenticateToken, async (req: any, res: any) => {'
);
code = code.replace(
  `      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      let finalVideoUrl = video;
      let finalThumbnailUrl = poster;
      if (files?.videoFile?.[0] && files.videoFile[0].size > 0) {
        finalVideoUrl = \`/uploads/\${files.videoFile[0].filename}\`;
      }
      if (files?.posterFile?.[0] && files.posterFile[0].size > 0) {
        finalThumbnailUrl = \`/uploads/\${files.posterFile[0].filename}\`;
      }`,
  `      let finalVideoUrl = video;
      let finalThumbnailUrl = poster;`
);

code = code.replace(
  'app.put("/api/admin/videos/:id", authenticateToken, upload.fields([{ name: \'videoFile\', maxCount: 1 }, { name: \'posterFile\', maxCount: 1 }]), async (req: any, res: any) => {',
  'app.put("/api/admin/videos/:id", authenticateToken, async (req: any, res: any) => {'
);
code = code.replace(
  `      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      let updateData: any = { title, description, category: genre, status: dbStatus };
      
      if (files?.videoFile?.[0] && files.videoFile[0].size > 0) {
        updateData.videoUrl = \`/uploads/\${files.videoFile[0].filename}\`;
      } else if (video) {
        updateData.videoUrl = video;
      }
      
      if (files?.posterFile?.[0] && files.posterFile[0].size > 0) {
        updateData.thumbnailUrl = \`/uploads/\${files.posterFile[0].filename}\`;
      } else if (poster) {
        updateData.thumbnailUrl = poster;
      }`,
  `      let updateData: any = { title, description, category: genre, status: dbStatus };
      if (video) updateData.videoUrl = video;
      if (poster) updateData.thumbnailUrl = poster;`
);

code = code.replace(
  'app.post("/api/admin/banners", authenticateToken, upload.array("images", 10), async (req: any, res: any) => {',
  'app.post("/api/admin/banners", authenticateToken, express.json(), async (req: any, res: any) => {'
);

code = code.replace(
  `      const files = req.files;
      
      if (!files || files.length === 0) return res.status(400).json({ error: "No image files provided" });
      
      const inserted = [];
      for (const file of files) {
        const newBanner = await db.insert(banners).values({
          title: title || "New Banner",
          imageUrl: \`/uploads/\${file.filename}\`,
          active: true
        }).returning();
        inserted.push(newBanner[0]);
      }`,
  `      const { imageUrls } = req.body;
      if (!imageUrls || imageUrls.length === 0) return res.status(400).json({ error: "No image urls provided" });
      
      const inserted = [];
      for (const url of imageUrls) {
        const newBanner = await db.insert(banners).values({
          title: title || "New Banner",
          imageUrl: url,
          active: true
        }).returning();
        inserted.push(newBanner[0]);
      }`
);

fs.writeFileSync('server.ts', code);
