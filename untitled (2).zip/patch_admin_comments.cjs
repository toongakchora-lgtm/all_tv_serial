const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const deleteCommentFunc = `
  const deleteComment = async (id: number) => {
    if (window.confirm("Are you sure you want to delete this comment?")) {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(\`/api/admin/comments/\${id}\`, {
          method: 'DELETE',
          headers: { Authorization: \`Bearer \${token}\` }
        });
        if (res.ok) {
          fetchComments();
        } else {
          alert("Failed to delete comment");
        }
      } catch(e) {
        alert("Error deleting comment");
      }
    }
  };
`;

if (!code.includes('const deleteComment =')) {
  code = code.replace(
    'const fetchComments = () => {',
    deleteCommentFunc + '\n  const fetchComments = () => {'
  );
  fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
}
