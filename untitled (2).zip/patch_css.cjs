const fs = require('fs');

let css = fs.readFileSync('src/index.css', 'utf8');

css = css.replace(
  '.hero {\n  position: relative; overflow: hidden; border-radius: 22px; aspect-ratio: 16 / 9;',
  '.hero {\n  position: relative; overflow: hidden; border-radius: 22px; min-height: 380px; /* aspect-ratio removed for mobile overflow */'
);

// adjust h1 size for mobile to prevent overflow
css = css.replace(
  '.hero-content h1 { font-size: clamp(34px, 7vw, 64px); line-height: .98; margin: 13px 0 12px; color: #fff; font-weight: 900; }',
  '.hero-content h1 { font-size: clamp(28px, 6vw, 64px); line-height: 1.1; margin: 12px 0 10px; color: #fff; font-weight: 900; }'
);

// adjust hero content padding
css = css.replace(
  '.hero-content { position: absolute; z-index: 2; left: 22px; right: 22px; bottom: 28px; max-width: 560px; }',
  '.hero-content { position: absolute; z-index: 2; left: 16px; right: 16px; bottom: 20px; max-width: 560px; }\n\n@media (min-width: 768px) {\n  .hero {\n    aspect-ratio: 16 / 9;\n    min-height: auto;\n  }\n  .hero-content { left: 22px; right: 22px; bottom: 28px; }\n}'
);

fs.writeFileSync('src/index.css', css);
