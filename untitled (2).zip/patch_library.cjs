const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes('import Library from "./pages/Library";')) {
  code = code.replace(
    'import SearchPage from "./pages/Search";',
    'import SearchPage from "./pages/Search";\nimport Library from "./pages/Library";'
  );
}

if (!code.includes('<Route path="/library" element={<Library />} />')) {
  code = code.replace(
    '<Route path="/search" element={<SearchPage />} />',
    '<Route path="/search" element={<SearchPage />} />\n          <Route path="/library" element={<Library />} />'
  );
}

// Ensure the icon is mapped in bottom nav and top actions
code = code.replace(
  '<Link to="/search" className="icon-btn"><Search width={18} /></Link>',
  '<Link to="/search" className="icon-btn"><Search width={18} /></Link>\n          <Link to="/library" className="icon-btn" style={{ marginLeft: "8px" }}><Bookmark width={18} /></Link>'
);

if (!code.includes('to="/library" className={path === \'/library\' ? \'active\' : \'\'}>Library</Link>')) {
  code = code.replace(
    '<Link to="/search" className={path === \'/search\' ? \'active\' : \'\'}>Search</Link>',
    '<Link to="/search" className={path === \'/search\' ? \'active\' : \'\'}>Search</Link>\n          <Link to="/library" className={path === \'/library\' ? \'active\' : \'\'}>Library</Link>'
  );
}

if (!code.includes('<Link to="/library"><span className="ico"><Bookmark width={22} /></span><span>Library</span></Link>')) {
  code = code.replace(
    '<Link to="/search"><span className="ico"><Search width={22} /></span><span>Search</span></Link>',
    '<Link to="/search"><span className="ico"><Search width={22} /></span><span>Search</span></Link>\n        <Link to="/library"><span className="ico"><Bookmark width={22} /></span><span>Library</span></Link>'
  );
}


fs.writeFileSync('src/App.tsx', code);
