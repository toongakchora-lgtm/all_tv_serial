const fs = require('fs');
let code = fs.readFileSync('src/firebase.ts', 'utf8');
if (!code.includes('getStorage')) {
  code = "import { getStorage } from 'firebase/storage';\n" + code;
  code += "\nexport const storage = getStorage(app);\n";
  fs.writeFileSync('src/firebase.ts', code);
}
