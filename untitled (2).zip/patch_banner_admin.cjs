const fs = require('fs');

let adminCode = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

const validationCode = `
    const checkAspectRatio = (file) => {
      return new Promise((resolve) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => {
          const ratio = img.width / img.height;
          // allow ~16:9 like 1.77
          if (ratio >= 1.7 && ratio <= 1.8) {
            resolve(true);
          } else {
            resolve(false);
          }
          URL.revokeObjectURL(url);
        };
        img.onerror = () => resolve(false);
        img.src = url;
      });
    };

    const isValid = await checkAspectRatio(newBannerImage);
    if (!isValid) {
      alert("Only 16:9 aspect ratio images are allowed (e.g., 1920x1080 or 1280x720).");
      return;
    }

    const formData = new FormData();`;

adminCode = adminCode.replace('    const formData = new FormData();', validationCode);

adminCode = adminCode.replace(
  '<label style={{display: \'block\', marginTop: \'12px\'}}>Banner image from gallery',
  '<label style={{display: \'block\', marginTop: \'12px\'}}>Banner image from gallery (16:9 only)\n                    <p style={{fontSize: \'12px\', color: \'var(--muted)\', marginTop: \'2px\'}}>Upload images with 16:9 size (e.g. 1920x1080) for best appearance on mobile and desktop.</p>'
);

fs.writeFileSync('src/pages/AdminDashboard.tsx', adminCode);
