const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes('import SearchPage from "./pages/Search";')) {
  code = code.replace(
    'import Discover from "./pages/Discover";',
    'import Discover from "./pages/Discover";\nimport SearchPage from "./pages/Search";'
  );
}

if (!code.includes('<Route path="/search" element={<SearchPage />} />')) {
  code = code.replace(
    '<Route path="/discover" element={<Discover />} />',
    '<Route path="/discover" element={<Discover />} />\n          <Route path="/search" element={<SearchPage />} />'
  );
}

fs.writeFileSync('src/App.tsx', code);
