const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');

if (!css.includes('.hero-actions .btn {')) {
  css = css.replace(
    '.hero-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 18px; }',
    '.hero-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 18px; }\n.hero-actions .btn { padding: 8px 12px; font-size: 13px; font-weight: 700; border-radius: 8px; }'
  );
  fs.writeFileSync('src/index.css', css);
}
