const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');

css = css.replace(
  'min-height: 380px; /* aspect-ratio removed for mobile overflow */',
  'aspect-ratio: 16 / 9;'
);

css = css.replace(
  '.hero img { width: 100%; height: 100%; object-fit: cover; opacity: .92; }',
  '.hero img { width: 100%; height: 100%; object-fit: cover; opacity: .92; position: absolute; inset: 0; }'
);

fs.writeFileSync('src/index.css', css);
