import { db } from './src/db/index.js';
import { videos } from './src/db/schema.js';
import { desc } from 'drizzle-orm';

async function main() {
  const result = await db.select().from(videos).orderBy(desc(videos.id)).limit(5);
  console.log(result);
  process.exit(0);
}
main();
