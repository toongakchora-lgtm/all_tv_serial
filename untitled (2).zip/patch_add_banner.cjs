const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

code = code.replace(
  /const addBanner = async \(\) => \{[\s\S]*?const token = localStorage\.getItem\("token"\);/,
  `const addBanner = async () => {
    const val = newBannerTitle.trim() || "New Banner";
    if (newBannerImages.length === 0) {
      alert("Please select at least one image");
      return;
    }

    const checkAspectRatio = (file) => {
      return new Promise((resolve) => {
        const url = URL.createObjectURL(file);
        const img = new Image();
        img.onload = () => {
          const ratio = img.width / img.height;
          if (ratio >= 1.7 && ratio <= 1.8) resolve(true);
          else resolve(false);
          URL.revokeObjectURL(url);
        };
        img.onerror = () => resolve(false);
        img.src = url;
      });
    };

    for (const img of newBannerImages) {
      const isValid = await checkAspectRatio(img);
      if (!isValid) {
        alert("Only 16:9 aspect ratio images are allowed.");
        return;
      }
    }

    const formData = new FormData();
    formData.append("title", val);
    for (let i = 0; i < newBannerImages.length; i++) {
      formData.append("images", newBannerImages[i]);
    }

    const token = localStorage.getItem("token");`
);

fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
