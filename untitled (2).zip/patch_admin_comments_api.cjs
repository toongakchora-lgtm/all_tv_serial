const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const apiString = `
  app.get("/api/admin/comments", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const commentsResult = await db.select({
        id: comments.id,
        videoId: comments.videoId,
        userId: comments.userId,
        text: comments.text,
        likes: comments.likes,
        createdAt: comments.createdAt,
        user: {
          id: users.id,
          displayName: users.displayName,
          email: users.email
        },
        video: {
          id: videos.id,
          title: videos.title
        }
      })
      .from(comments)
      .leftJoin(users, eq(comments.userId, users.id))
      .leftJoin(videos, eq(comments.videoId, videos.id))
      .orderBy(desc(comments.createdAt));

      res.json({ comments: commentsResult });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  app.delete("/api/admin/comments/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: "Unauthorized" });
      }
      
      const commentId = parseInt(req.params.id);
      await db.delete(comments).where(eq(comments.id, commentId));
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to delete comment" });
    }
  });
`;

if (!code.includes('/api/admin/comments')) {
  code = code.replace(
    'app.get("/api/videos/:id/comments",',
    apiString + '\n  app.get("/api/videos/:id/comments",'
  );
  fs.writeFileSync('server.ts', code);
}

