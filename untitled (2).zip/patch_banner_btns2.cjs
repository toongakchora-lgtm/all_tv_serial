const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');

css = css.replace(
  '.hero-actions .btn { padding: 8px 12px; font-size: 13px; font-weight: 700; border-radius: 8px; }',
  '.hero-actions .btn { padding: 4px 8px; font-size: 11px; font-weight: 600; border-radius: 6px; height: 26px; }'
);

fs.writeFileSync('src/index.css', css);
