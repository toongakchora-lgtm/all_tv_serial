const fs = require('fs');
let code = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');

if (!code.includes('const [homeSections, setHomeSections] = useState<any[]>')) {
  code = code.replace(
    'const [banners, setBanners] = useState<any[]>([]);',
    'const [banners, setBanners] = useState<any[]>([]);\n  const [homeSections, setHomeSections] = useState<any[]>([]);'
  );
  
  code = code.replace(
    'if (data.website_name) setWebsiteName(data.website_name);\n        if (data.support_email) setSupportEmail(data.support_email);',
    'if (data.website_name) setWebsiteName(data.website_name);\n        if (data.support_email) setSupportEmail(data.support_email);\n        if (data.homepage_sections) {\n          try { setHomeSections(JSON.parse(data.homepage_sections)); } catch(e) {}\n        } else {\n          setHomeSections([\n            { id: "1", title: "Continue Watching", type: "continue_watching", landscape: true },\n            { id: "2", title: "Short Dramas", type: "category", category: "Short Dramas", landscape: false },\n            { id: "3", title: "Movies & Web Series", type: "category", category: "Movies", landscape: true },\n            { id: "4", title: "Trending Now", type: "trending", landscape: false }\n          ]);\n        }'
  );

  code = code.replace(
    `{ id: 'settings', label: 'Settings', icon: <Settings width={18} /> },`,
    `{ id: 'home_sections', label: 'Home Sections', icon: <Menu width={18} /> },\n    { id: 'settings', label: 'Settings', icon: <Settings width={18} /> },`
  );

  const saveFunc = `
  const saveHomeSections = async (sectionsToSave: any[]) => {
    const token = localStorage.getItem("token");
    try {
      await fetch("/api/admin/settings", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: \`Bearer \${token}\`
        },
        body: JSON.stringify({ key: "homepage_sections", value: JSON.stringify(sectionsToSave) })
      });
      setHomeSections(sectionsToSave);
      alert("Sections saved successfully!");
    } catch(e) {
      console.error(e);
      alert("Failed to save sections");
    }
  };
`;
  code = code.replace(
    'const handleSaveSettings = async () => {',
    saveFunc + '\n  const handleSaveSettings = async () => {'
  );

  const uiString = `
          <section className={\`admin-page \${activeSection === 'home_sections' ? 'active' : ''}\`}>
            <div className="admin-grid2">
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Home Page Sections</h3>
                </div>
                <div className="admin-card-body admin-list">
                  {homeSections.map((sec, i) => (
                    <div key={sec.id} className="admin-list-item" style={{flexDirection: 'column', alignItems: 'flex-start', background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid var(--line)'}}>
                      <div style={{display: 'flex', width: '100%', gap: '10px', alignItems: 'center'}}>
                        <input
                          value={sec.title}
                          onChange={e => {
                            const newSec = [...homeSections];
                            newSec[i].title = e.target.value;
                            setHomeSections(newSec);
                          }}
                          style={{flex: 1, padding: '6px 10px', border: '1px solid var(--line)', borderRadius: '6px'}}
                        />
                        <button className="admin-btn" style={{padding: '6px 10px'}} onClick={() => {
                          if (i > 0) {
                            const newSec = [...homeSections];
                            const temp = newSec[i];
                            newSec[i] = newSec[i-1];
                            newSec[i-1] = temp;
                            setHomeSections(newSec);
                          }
                        }}>Up</button>
                        <button className="admin-btn" style={{padding: '6px 10px'}} onClick={() => {
                          if (i < homeSections.length - 1) {
                            const newSec = [...homeSections];
                            const temp = newSec[i];
                            newSec[i] = newSec[i+1];
                            newSec[i+1] = temp;
                            setHomeSections(newSec);
                          }
                        }}>Down</button>
                        <button className="admin-btn danger" style={{background: '#fff1f2', color: '#ef4444', borderColor: '#fecdd3', padding: '6px 10px'}} onClick={() => {
                          if (window.confirm('Delete section?')) {
                            const newSec = homeSections.filter(s => s.id !== sec.id);
                            setHomeSections(newSec);
                          }
                        }}>Delete</button>
                      </div>
                      <div style={{display: 'flex', gap: '10px', marginTop: '10px', fontSize: '13px', color: 'var(--text)', width: '100%', alignItems: 'center', flexWrap: 'wrap'}}>
                        <select
                          value={sec.type}
                          onChange={e => {
                            const newSec = [...homeSections];
                            newSec[i].type = e.target.value;
                            setHomeSections(newSec);
                          }}
                          style={{padding: '6px', borderRadius: '4px', border: '1px solid var(--line)'}}
                        >
                          <option value="continue_watching">Continue Watching</option>
                          <option value="trending">Trending Now</option>
                          <option value="category">Category</option>
                        </select>
                        {sec.type === 'category' && (
                          <input
                            placeholder="Category Name (e.g. Romance)"
                            value={sec.category || ''}
                            onChange={e => {
                              const newSec = [...homeSections];
                              newSec[i].category = e.target.value;
                              setHomeSections(newSec);
                            }}
                            style={{padding: '6px', borderRadius: '4px', border: '1px solid var(--line)', flex: 1}}
                          />
                        )}
                        <label style={{display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 600}}>
                          <input
                            type="checkbox"
                            checked={sec.landscape || false}
                            onChange={e => {
                              const newSec = [...homeSections];
                              newSec[i].landscape = e.target.checked;
                              setHomeSections(newSec);
                            }}
                          />
                          Landscape Cards
                        </label>
                      </div>
                    </div>
                  ))}
                  <button className="admin-btn primary" style={{marginTop: '16px', width: '100%', padding: '12px'}} onClick={() => saveHomeSections(homeSections)}>Save Changes</button>
                </div>
              </div>
              <div className="admin-card">
                <div className="admin-card-head">
                  <h3>Add New Section</h3>
                </div>
                <div className="admin-card-body">
                  <button className="admin-btn" style={{width: '100%', padding: '10px'}} onClick={() => {
                    const newSec = [...homeSections, { id: Date.now().toString(), title: 'New Section', type: 'category', category: '', landscape: false }];
                    setHomeSections(newSec);
                  }}>+ Add Section</button>
                </div>
              </div>
            </div>
          </section>
`;

  code = code.replace(
    '          <section className={`admin-page ${activeSection === \'settings\' ? \'active\' : \'\'}`}>',
    uiString + '\n          <section className={`admin-page ${activeSection === \'settings\' ? \'active\' : \'\'}`}>'
  );

  fs.writeFileSync('src/pages/AdminDashboard.tsx', code);
}
